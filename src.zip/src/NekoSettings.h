/************************************

    Neko's configuration header file

 *************************************/

#ifndef _NEKO_NEKO_SETTINGS_H_
#define _NEKO_NEKO_SETTINGS_H_

#include "framework.h"

/* Settings are stored in config.ini next to the executable (portable, no registry).
   Each configuration key "Neko-ng[\<name>]" maps to one INI section. */

class CNekoSettings {
public:
    CNekoSettings( LPCWSTR key, BOOL fCreate = TRUE );
    ~CNekoSettings();

	BOOL IsOpen();

    BOOL GetString( LPCWSTR keyname, LPWSTR result, ULONG size );
    BOOL GetInt( LPCWSTR keyname, DWORD * result );
    BOOL GetBool( LPCWSTR keyname, BOOL * result );

    BOOL SetString( LPCWSTR keyname, LPCWSTR value );
    BOOL SetInt( LPCWSTR keyname, DWORD value );
    BOOL SetBool( LPCWSTR keyname, BOOL value );

    BOOL DeleteValue( LPCWSTR keyname );
    BOOL DeleteSection( LPCWSTR section );

private:
    WCHAR m_szIniPath[MAX_PATH];
    WCHAR m_szSection[MAX_PATH];
};

/* Sanitizes config.ini against corruption left behind by older builds:
   bogus sentinel sections (with or without 0x01 control characters),
   leaked sentinel values, repeated sections and repeated keys.
   The file is rewritten only when garbage was actually found; healthy
   files keep their exact bytes. */
BOOL NekoCfgCleanupCorruptSections( void );

#endif // _NEKO_NEKO_SETTINGS_H_
