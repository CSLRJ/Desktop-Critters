// Pet.cpp: implementation of the CPet class.
//
//////////////////////////////////////////////////////////////////////

#include "Pet.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPet::CPet()
{
	//no skin table (the skin cache owns the icon tables)
	m_pSkinTable = nullptr;

	//prepare empty icon table
	m_nIcons = 0;
	m_nLastIcon = -1;
	m_hIcons = nullptr;

	//set initial and old position
	m_ptPosition.x = 0;
	m_ptPosition.y = 0;
	m_ptOldPosition.x = -1;
	m_ptOldPosition.y = -1;

	//set initial size and scale
	m_sizeImage.cx = 0;
	m_sizeImage.cy = 0;
	m_sizeOriginal.cx = 0;
	m_sizeOriginal.cy = 0;
    m_fScale = 1.0f;

	//set initial bounding box (none)
	SetRect( &m_rcBounds, -1, -1, -1, -1 );
}



CPet::~CPet()
{
	//delete the images
	DestroyImages();
}


//////////////////////////////////////////////////////////////////////
// Member Functions
//////////////////////////////////////////////////////////////////////


void CPet::SetImages( SkinIconTable* pTable )
{
	//drop the previous skin table (releases its cache reference)
	DestroyImages();

	//adopt the shared table; the cache keeps ownership of the icons, so no
	//CopyIcon() copies are made here - pets drawing the same skin share the
	//same icon handles
	m_pSkinTable = pTable;
	if( pTable != nullptr )
	{
		m_hIcons = pTable->phIcons;
		m_nIcons = pTable->nIcons;

		//record the mask's native size and the scaled display size
		m_sizeOriginal.cx = pTable->sizeOriginal.cx;
		m_sizeOriginal.cy = pTable->sizeOriginal.cy;
		m_sizeImage.cx = int( m_sizeOriginal.cx * m_fScale );
		m_sizeImage.cy = int( m_sizeOriginal.cy * m_fScale );
	}

	//reset last drawn icon index
	m_nLastIcon = -1;
}



void CPet::DestroyImages()
{
	//the icons belong to the shared skin cache - just drop our reference;
	//the cache frees the icons when the last pet releases them
	if( m_pSkinTable != nullptr )
	{
		SkinCache_ReleaseIcons( m_pSkinTable );
		m_pSkinTable = nullptr;
	}

	//drop the borrowed pointers
	m_hIcons = nullptr;
	m_nIcons = 0;
	m_nLastIcon = -1;
}



void CPet::SetImage( int nImage )
{
	//nothing to draw before the skin table has been adopted
	if( m_nIcons <= 0 ) return;

	//only draw if the image has changed
	if( nImage != m_nLastIcon )
	{
		Erase();
		Draw( nImage );
		m_nLastIcon = nImage;
	}
}



void CPet::MoveTo(int nNewX, int nNewY)
{
	if( m_ptOldPosition.x == -1 )
	{
		//set old position to the current position as we've not been moved before
		m_ptOldPosition.x = nNewX;
		m_ptOldPosition.y = nNewY;
	}
	else
	{
		//store current position
		m_ptOldPosition.x = m_ptPosition.x;
		m_ptOldPosition.y = m_ptPosition.y;
	}

	//remove current
	Erase();

	//change current position
	m_ptPosition.x = nNewX;
	m_ptPosition.y = nNewY;

	//redraw
	Draw( m_nLastIcon );
}

void CPet::SetImageAndMoveTo(int nImage, int nNewX, int nNewY)
{
	//change image
	m_nLastIcon = nImage;

	//move
	MoveTo( nNewX, nNewY );
}


void CPet::SetScale(float fScale)
{
    if( fScale != 0.0f )
        m_fScale = fScale;
    else
        m_fScale = 1.0f;

    //keep the displayed size in sync with the new scale: the window size,
    //drawing and region building all derive from m_sizeImage. Before
    //SetImages() m_sizeOriginal is still empty, so there is nothing to do.
    if( m_sizeOriginal.cx > 0 && m_sizeOriginal.cy > 0 )
    {
        m_sizeImage.cx = int( m_sizeOriginal.cx * m_fScale );
        m_sizeImage.cy = int( m_sizeOriginal.cy * m_fScale );
    }
}

RECT CPet::GetWorkArea()
{
    //default: primary monitor's work area
    RECT rc;
    if( !SystemParametersInfoW( SPI_GETWORKAREA, 0, &rc, 0 ) )
        SetRect( &rc, 0, 0, GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ) );
    return rc;
}
