// Pet.h: interface for the CPet class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _NEKO_PET_H_
#define _NEKO_PET_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "framework.h"
#include "SkinCache.h"

class CPet {

public:
	//constructor/destructor
	CPet();
	virtual ~CPet();

	//public configuration functions
	//adopt a shared icon table from the skin cache. The table carries one
	//reference which the pet takes over; it is released in DestroyImages().
	//Pass nullptr to clear the pet's images.
	virtual void SetImages( SkinIconTable* pTable );
	virtual void SetScale( float fScale );

	//notifications & environment queries
	virtual void OnScaleChanged() {}            //called after SetScale to refresh window/region
	virtual RECT GetWorkArea();                 //work area the pet may occupy (virtual: multi-monitor)

	//fall-pending flag (set when the pet is dropped above the work area floor)
	virtual BOOL IsFallPending()    { return FALSE; }
	virtual void ClearFallPending() {}

	//public interface
	virtual void SetImageAndMoveTo( int nImage, int nNewX, int nNewY );
	virtual void MoveTo( int nNewX, int nNewY );
	virtual void SetImage( int nImage );

	//data member access
	inline RECT   GetBoundsRect()  { return m_rcBounds; };
	inline POINT& GetPosition()	   { return m_ptPosition; };
	inline POINT& GetOldPosition() { return m_ptOldPosition; };
    inline SIZE   GetSize()        { return m_sizeImage; };

protected:

	//pure virtual functions
	virtual void Erase() = 0;
	virtual void Draw( int nImage ) = 0;

	//image destruction
	virtual void DestroyImages();

	//icon information: the icons themselves are owned by the shared skin
	//cache; we only hold the table reference and borrow the icon pointers
	SkinIconTable* m_pSkinTable;
	HICON* m_hIcons;
	int m_nIcons;
	int m_nLastIcon;

	//position & size information
	POINT m_ptPosition;
	POINT m_ptOldPosition;
	SIZE  m_sizeImage;     // scaled (display) size
	SIZE  m_sizeOriginal;  // unscaled icon mask size — kept verbatim from the
	                       // mask bitmap so region-building doesn't have to
	                       // reconstruct it via lossy int(scaled/m_fScale).
	float m_fScale;

	//bounding box information
	RECT m_rcBounds;
};

#endif // _NEKO_PET_H_
