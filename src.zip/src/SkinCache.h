// SkinCache.h: process-wide, reference-counted cache of skin images.
//
// Every pet drawing the same skin shares one HICON table and one set of
// per-frame window regions instead of each pet holding private copies.
// A skin is loaded on first use only (never preloaded) and freed as soon
// as the last pet releases it, so switching skins cannot accumulate the
// unused skins' images.
#ifndef _NEKO_SKIN_CACHE_H_
#define _NEKO_SKIN_CACHE_H_

#include "framework.h"
#include "Skins.h"

//one cached skin: NEKO_SKIN_FRAMES icons loaded from this executable's resources
struct SkinIconTable
{
    HICON* phIcons;       //icon handles (owned by the cache)
    int    nIcons;        //number of icons in the table
    SIZE   sizeOriginal;  //native (unscaled) mask size of the first icon
    LONG   nRefs;         //number of pets currently using this table
};

//one cached region set: the per-frame window regions for one skin at one scale
struct SkinRegionSet
{
    float          fScale;   //scale the regions were built for
    HRGN*          phRgns;   //region handles (owned by the cache)
    int            nRgns;
    int            nSkin;    //skin index this set belongs to
    LONG           nRefs;    //number of pets currently using this set
    SkinRegionSet* pNext;    //next region set of the same skin
};

//acquire (load on first use) the icon table of a skin. The caller receives
//one reference, which CPet::SetImages() adopts; anything else must balance
//it with SkinCache_ReleaseIcons(). Returns nullptr when the skin's resources
//are missing/corrupt (callers fall back to skin 0).
SkinIconTable* SkinCache_AcquireIcons( int nSkin );

//drop one icon table reference; when the last one goes, the icons are freed
void SkinCache_ReleaseIcons( SkinIconTable* pTable );

//acquire (build on first use) the window regions of a skin at a scale.
//pTable must be a table the caller currently holds a reference to.
SkinRegionSet* SkinCache_AcquireRegions( SkinIconTable* pTable, float fScale );

//drop one region set reference; freed when the last one goes
void SkinCache_ReleaseRegions( SkinRegionSet* pSet );

//process shutdown safety net: force-release anything still cached
void SkinCache_Shutdown();

/* SkinCache_TrimWorkingSet - evicts the process working set. Skin icon data
 * lives in the executable's resource pages; once the icons are decoded into
 * kernel GDI objects those pages are never read again, so trimming after a
 * skin load keeps the resident set small (pages fault back on demand). */
void SkinCache_TrimWorkingSet();

#endif // _NEKO_SKIN_CACHE_H_
