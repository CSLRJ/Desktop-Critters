/************************************
	Neko for Windows NT
 *************************************/

#include "Neko98.h"

#include "Tray.h"
#include "NekoSettings.h"
#include "NekoCommon.h"
#include "resource.h"
#include "Neko.h"
#include "Skins.h"

//global variables
HINSTANCE g_hInstance = nullptr;
HWND g_hWndMain = nullptr;
BOOL g_fTaskbar = TRUE;
CTray * Tray = nullptr;

int g_nNumCats = 0;
typedef CNeko* PNeko;
PNeko* g_NekoArray = nullptr; //array of CNeko pointers
DWORD g_dwSleepTime = 100;

BOOL g_fNeedReinit = TRUE;
BOOL g_fPaused = FALSE;

static HICON kMainIcon = nullptr;
static HICON kSmallIcon = nullptr;

/* SetPaused - pauses/resumes the pet updates by killing/re-arming the timer */
static void SetPaused( BOOL fPaused )
{
    if( g_fPaused == fPaused ) return;
    g_fPaused = fPaused;
    if( g_fPaused )
        KillTimer( g_hWndMain, ID_TIMER_NEKO );
    else
        SetTimer( g_hWndMain, ID_TIMER_NEKO, 200, nullptr );  // same period as WinMain
}

/* ExecuteConfigProcess - runs the configuration program *******************************/
static bool ExecuteConfigProcess() {
  // Locate NekoCFG.exe next to this executable instead of relying on the
  // current working directory (which varies with how Neko was started).
  WCHAR szExeDir[MAX_PATH + 1];
  DWORD dwLen = GetModuleFileNameW( nullptr, szExeDir, MAX_PATH );
  if( dwLen == 0 || dwLen >= MAX_PATH ) {
    MessageBoxW( nullptr, L"Neko was unable to locate its own executable.", L"Configure Neko-ng", MB_ICONEXCLAMATION );
    return false;
  }
  // trim the string to the directory containing this EXE
  WCHAR * pSlash = szExeDir + lstrlenW( szExeDir );
  while( pSlash > szExeDir && *pSlash != L'\\' ) pSlash--;
  *pSlash = L'\0';
  // full path of the configuration program. Prefer the renamed portable
  // deployment (Desktop_Critters_CFG.exe) and fall back to the original
  // build-output name (NekoCFG.exe) so development setups keep working.
  WCHAR szCfgPath[MAX_PATH + 32];
  wsprintfW( szCfgPath, L"%s\\Desktop_Critters_CFG.exe", szExeDir );
  DWORD dwCfgAttr = GetFileAttributesW( szCfgPath );
  if( dwCfgAttr == INVALID_FILE_ATTRIBUTES || (dwCfgAttr & FILE_ATTRIBUTE_DIRECTORY) )
    wsprintfW( szCfgPath, L"%s\\NekoCFG.exe", szExeDir );
  if ((int)(INT_PTR)ShellExecuteW(nullptr, L"open", szCfgPath, 0, szExeDir, SW_SHOWNORMAL) <= 32 ) {
    MessageBoxW( nullptr, L"Neko was unable to start the configuration program\n'NekoCFG.exe'\n\nMake sure that this file is in the same folder as the main Neko-ng program.", L"Configure Neko-ng", MB_ICONEXCLAMATION );
    return false;
  } else {
    return true;
  }
}

/* SetAllScales - applies the given scale percentage to every cat */
static void SetAllScales( DWORD dwPercent )
{
    for( int i = 0; i < g_nNumCats; i++ )
        g_NekoArray[i]->SetScalePercent( dwPercent );
}

/* ShowPetContextMenu - context menu of a pet window (skin / size / pause / exit) *******/
static void ShowPetContextMenu( CAlwaysOnTopPet* pPet )
{
    if( g_nNumCats <= 0 || g_NekoArray == nullptr ) return;

    //find the cat that owns this pet window (fall back to the first cat)
    CNeko* pNeko = g_NekoArray[0];
    for( int i = 0; i < g_nNumCats; i++ )
    {
        if( g_NekoArray[i]->GetPet() == pPet ) { pNeko = g_NekoArray[i]; break; }
    }
    if( pNeko == nullptr ) return;

    //build the menu
    POINT pt;
    GetCursorPos( &pt );

    HMENU hMenu = CreatePopupMenu();
    HMENU hSkinMenu = CreatePopupMenu();
    HMENU hScaleMenu = CreatePopupMenu();
    //one entry per built-in skin, straight from the shared skin table
    //(entries and their order match the NekoCFG Display combo exactly)
    for( int s = 0; s < (int)NEKO_NUM_SKINS; s++ )
        AppendMenuW( hSkinMenu, MF_STRING | (pNeko->GetSkin() == s ? MF_CHECKED : 0), IDM_PET_SKINBASE + s, kNekoSkins[s].szName );
    //integer scale factors only: they keep the pixels sharp at every size
    AppendMenuW( hScaleMenu, MF_STRING | (pNeko->GetScale() == 100 ? MF_CHECKED : 0), IDM_PET_SCALEBASE + 100, L"100%" );
    AppendMenuW( hScaleMenu, MF_STRING | (pNeko->GetScale() == 200 ? MF_CHECKED : 0), IDM_PET_SCALEBASE + 200, L"200%" );
    AppendMenuW( hScaleMenu, MF_STRING | (pNeko->GetScale() == 300 ? MF_CHECKED : 0), IDM_PET_SCALEBASE + 300, L"300%" );
    AppendMenuW( hScaleMenu, MF_STRING | (pNeko->GetScale() == 400 ? MF_CHECKED : 0), IDM_PET_SCALEBASE + 400, L"400%" );

    AppendMenuW( hMenu, MF_POPUP, (UINT_PTR)hSkinMenu,  L"Skin" );
    AppendMenuW( hMenu, MF_POPUP, (UINT_PTR)hScaleMenu, L"Size" );
    AppendMenuW( hMenu, MF_STRING | (g_fPaused ? MF_CHECKED : 0), IDM_PET_PAUSE, g_fPaused ? L"Resume" : L"Pause" );
    AppendMenuW( hMenu, MF_SEPARATOR, 0, nullptr );
    AppendMenuW( hMenu, MF_STRING, IDM_PET_EXIT, L"Exit" );

    //show the menu (same convention as the tray menu)
    SetForegroundWindow( g_hWndMain );
    int nCmd = TrackPopupMenu( hMenu, TPM_RETURNCMD|TPM_RIGHTBUTTON|TPM_NONOTIFY, pt.x, pt.y, 0, g_hWndMain, nullptr );
    PostMessageW( g_hWndMain, WM_NULL, 0, 0 );
    DestroyMenu( hMenu );

    //dispatch
    if( nCmd >= IDM_PET_SKINBASE && nCmd < IDM_PET_SKINBASE + (int)NEKO_NUM_SKINS )
        pNeko->SetSkin( nCmd - IDM_PET_SKINBASE );
    else if( nCmd >= IDM_PET_SCALEBASE && nCmd <= IDM_PET_SCALEBASE + 400 )
        SetAllScales( nCmd - IDM_PET_SCALEBASE );
    else if( nCmd == IDM_PET_PAUSE )
        SetPaused( !g_fPaused );
    else if( nCmd == IDM_PET_EXIT )
        PostMessageW( g_hWndMain, WM_CLOSE, 0, 0 );
}

/* LoadConfiguration - reloads the program configuration *******************************/
void LoadConfiguration()
{
    //load in the new global settings
    CNekoSettings * NekoSettings = new CNekoSettings( szNekoCfgSection );
    NekoSettings->GetBool( szNekoTaskbarKey, &g_fTaskbar );

    //delete all existing Nekos
    int i;
    for( i = 0; i < g_nNumCats; i++ ) delete g_NekoArray[i];
    delete[] g_NekoArray;

    //load in new cats list (capped: a corrupt file must not be able to
    //make us allocate an oversized array)
    DWORD dwNumCats = 0;
    NekoSettings->GetInt( szNekoNumCatsKey, &dwNumCats );
    if( dwNumCats > NEKO_MAX_CATS ) dwNumCats = NEKO_MAX_CATS;

    //collect the valid, unique cat names first; corrupt or duplicate
    //entries are skipped instead of turning into bogus cats
    WCHAR szNames[NEKO_MAX_CATS][MAX_NEKO_NAME];
    DWORD dwValid = 0;

    for( DWORD j = 0; j < dwNumCats; j++ )
    {
        //build the key index
        WCHAR szSubKey[MAX_PATH], szName[MAX_NEKO_NAME];
        wsprintfW( szSubKey, L"%d", j );
        szName[0] = L'\0';

        //load this cat's name; skip entries that are missing or invalid
        if( NekoSettings->GetString( szSubKey, szName, (MAX_NEKO_NAME-1) * sizeof(WCHAR) ) &&
            IsValidCatName( szName ) )
        {
            //skip duplicates so every cat keeps a unique section
            BOOL fDup = FALSE;
            for( DWORD k = 0; k < dwValid; k++ )
            {
                if( lstrcmpW( szNames[k], szName ) == 0 ) { fDup = TRUE; break; }
            }
            if( fDup ) continue;

            lstrcpynW( szNames[dwValid], szName, MAX_NEKO_NAME );
            dwValid++;
        }
    }

    //create one Neko per valid name
    g_NekoArray = new PNeko[dwValid > 0 ? dwValid : 1];
    for( DWORD j = 0; j < dwValid; j++ )
        g_NekoArray[j] = new CNeko( szNames[j] );
    g_nNumCats = (int)dwValid;

    if( g_nNumCats == 0 )
    {
        //nothing usable in the file - fall back to the default anonymous cat
        g_NekoArray[0] = new CNeko();
        g_nNumCats = 1;
    }

	//erase the Neko settings
    delete NekoSettings;

	//calculate new sleep time
	g_dwSleepTime = 100;
	if( g_nNumCats <= 20 ) g_dwSleepTime = 200 - ( 5 * g_nNumCats );

    //update task bar
    if( g_fTaskbar )
    {
        if( Tray->GetCount() == 0 )
			Tray->AddIcon( g_hWndMain, LoadIconW( g_hInstance, MAKEINTRESOURCEW( IDI_AWAKE )), 1 );
    }
    else
    {
        if( Tray->GetCount() > 0 ) 
			Tray->RemoveIcon( g_hWndMain, 1 );
    }

    //all pets are built, their windows shown and the tray updated by now.
    //The per-pet trim inside SetImages runs before the rest of the startup
    //work (first paint, tray update, remaining pets), so the pages touched
    //afterwards would stay resident forever; trimming once here gives the
    //same on-demand fault-back behaviour at startup as after a skin switch.
    SkinCache_TrimWorkingSet();

}


/* WndProc - message processing function for the hidden Neko window ********************/
static LRESULT CALLBACK WndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
    switch( message )
    {
        case WM_DESTROY:
			//terminate the program
            PostQuitMessage( 0 );
            break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_ABOUT:
                    DialogBoxW( g_hInstance, MAKEINTRESOURCEW(IDD_ABOUTBOX), hWnd, (DLGPROC)AboutDlgProc );
                    break;
                case ID_SETTINGS:
                    ExecuteConfigProcess();
                    break;

                case ID_EXIT: 
                    PostQuitMessage( 0 ); 
                    break;
            }
            break;

        case WM_DEVMODECHANGE:
        case WM_DISPLAYCHANGE:
        case WM_SETTINGCHANGE:
        case MY_UPDATENEKO:
            g_fNeedReinit = TRUE;
            break;

        case MY_NOTIFYICON:
            switch( lParam )
            {
                case WM_LBUTTONDBLCLK:
                    ExecuteConfigProcess();
                    break;

                case WM_RBUTTONUP:
                    //this line is needed to make the menu go away!
                    //(from Windows Developer FAQ [Robert Mashlan])
                    SetForegroundWindow( hWnd );

                    //show the context menu
                    Tray->ShowPopupMenu( hWnd );
                    break;
            }
            break;

        case WM_TIMER:
        {
            //check to see if stuff needs reinitialisation
            if( g_fNeedReinit )
            {
                LoadConfiguration();
                g_fNeedReinit = FALSE;
            }

			//update all Nekos
			for( int i = 0; i < g_nNumCats; i++ ) g_NekoArray[i]->Update();
            break;
        }

        default:
            return DefWindowProcW( hWnd, message, wParam, lParam );
    }

    return 0;
}


/* InitApplication - program initialisation function ***********************************/
static BOOL InitApplication(HINSTANCE hInstance) {
    //store the instance handle
    g_hInstance = hInstance;

  kMainIcon = LoadIconW(g_hInstance, MAKEINTRESOURCEW(IDI_AWAKE));
  kSmallIcon = (HICON)LoadImageW(g_hInstance, MAKEINTRESOURCEW(IDI_AWAKE), IMAGE_ICON,
                                 GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),
                                 LR_DEFAULTCOLOR);

	//create the (hidden) window
    WNDCLASSW wc;
    wc.style = 0;
    wc.lpfnWndProc = (WNDPROC)WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = nullptr;
    wc.hCursor = nullptr;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName = nullptr;
    wc.lpszClassName = szNekoClassName;

    if( RegisterClassW(&wc) )
    {
        //create the window
        g_hWndMain = CreateWindowW( szNekoClassName, szNekoWindowTitle, WS_OVERLAPPEDWINDOW, 0, 0, 0, 0, nullptr, nullptr, hInstance, nullptr);

		if( g_hWndMain == nullptr ) return FALSE;
    }
	else
		return FALSE;

    //initialise random number generator
    srand( GetTickCount() );
    return TRUE;
}


/* WinMain - program entry point *******************************************************/
int APIENTRY wWinMain(HINSTANCE hInstance,
                      HINSTANCE hPrevInstance,
                      LPWSTR lpCmdLine,
                      int iCmdShow) {
  UNREFERENCED_PARAMETER(hPrevInstance);
	//check for previous version & unload both if it's found
	HWND hWndOld = FindWindowW( szNekoClassName, szNekoWindowTitle );
	if( hWndOld != nullptr )
	{
		PostMessageW( hWndOld, WM_QUIT, 0, 0 );
		return FALSE;
	}

    //opt in to DPI awareness where supported (no-op on XP)
    EnableProcessDPIAwareness();

    //ensure the common control library is loaded
    InitCommonControls();

    //initialise the program
    if( !InitApplication( hInstance ) ) return FALSE;

    //create the tray object
    Tray = new CTray( hInstance );

    //hook up the pet context menu
    CAlwaysOnTopPet::s_pfnContextMenu = ShowPetContextMenu;

    //set a timer to update Neko
    SetTimer( g_hWndMain, ID_TIMER_NEKO, 200, nullptr );

    MSG msg;
    while( GetMessageW( &msg, nullptr, 0, 0 ) )
    {
		//pass the message onto our WndProc
		TranslateMessage( &msg );
		DispatchMessageW( &msg );
	}

    //remove the timer
    KillTimer( g_hWndMain, ID_TIMER_NEKO );

    //delete all Nekos
    for( int i = 0; i < g_nNumCats; i++ ) delete g_NekoArray[i];
    delete[] g_NekoArray;

    //safety net: force-release any skin cache entries still referenced
    SkinCache_Shutdown();

    //remove the taskbar icon
    if( g_fTaskbar ) Tray->RemoveIcon( g_hWndMain, 1 );
    delete Tray;

    return (int)msg.wParam;
}

INT_PTR CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
  UNREFERENCED_PARAMETER(lParam);
  switch (uMsg) {
    case WM_INITDIALOG:
      // Set icon in titlebar of about dialog
      static const HICON kAboutIcon = LoadIconW(g_hInstance, MAKEINTRESOURCEW(IDI_ABOUTICON));
      SendMessageW(hDlg, WM_SETICON, ICON_BIG, (LPARAM)kAboutIcon);
      SendMessageW(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)kAboutIcon);
      return TRUE;
    case WM_CLOSE:
      EndDialog( hDlg, TRUE );
      return TRUE;
    case WM_COMMAND:
      if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
        EndDialog(hDlg, LOWORD(wParam));
        return TRUE;
      }
      break;
    default:
      break;
  }

  return FALSE;
}
