/************************************

    Neko's configuration (config.ini, portable)

 *************************************/

#include "NekoSettings.h"
#include <cwchar>

//sentinel returned when a value does not exist in the INI file
#define NEKO_CFG_NOTFOUND  L"\x01NEKO_CFG_NOTFOUND\x01"

//locate config.ini next to the executable, never depend on the current directory
static BOOL BuildIniPath( LPWSTR result, ULONG cch )
{
    DWORD dwLen = GetModuleFileNameW( nullptr, result, cch );
    if( dwLen == 0 || dwLen >= cch )
        return FALSE;

    LPWSTR pSlash = wcsrchr( result, L'\\' );
    if( pSlash == nullptr )
        return FALSE;

    lstrcpyW( pSlash + 1, L"config.ini" );
    return TRUE;
}

//"Neko-ng[\<name>]" maps to INI section "Neko-ng" / "<name>"
static void BuildSectionName( LPCWSTR key, LPWSTR result, ULONG cch )
{
    LPCWSTR pLast = wcsrchr( key, L'\\' );
    lstrcpynW( result, (pLast != nullptr) ? pLast + 1 : key, cch );
}

CNekoSettings::CNekoSettings( LPCWSTR key, BOOL fCreate /*TRUE*/ )
{
	m_szIniPath[0] = L'\0';
	m_szSection[0] = L'\0';

	if( BuildIniPath( m_szIniPath, MAX_PATH ) )
		BuildSectionName( key, m_szSection, MAX_PATH );
}

CNekoSettings::~CNekoSettings()
{
}

BOOL CNekoSettings::IsOpen()
{
	return( m_szSection[0] != L'\0' );
}

BOOL CNekoSettings::GetString( LPCWSTR keyname, LPWSTR result, ULONG size )
{
    if( m_szSection[0] == L'\0' )
        return FALSE;

    //callers pass the buffer size in bytes; GetPrivateProfileStringW counts characters
    ULONG cch = size / sizeof(WCHAR);
    if( cch == 0 )
        return FALSE;

    //read into a local buffer first: when the key is missing the sentinel
    //would otherwise stay in the caller's buffer and leak out as a bogus
    //pet name (which then gets written back into the INI file)
    WCHAR szTemp[MAX_PATH];
    GetPrivateProfileStringW( m_szSection, keyname, NEKO_CFG_NOTFOUND, szTemp, ARRAYSIZE(szTemp), m_szIniPath );

    if( lstrcmpW( szTemp, NEKO_CFG_NOTFOUND ) == 0 ||
        lstrcmpW( szTemp, L"NEKO_CFG_NOTFOUND" ) == 0 ) //bare-text variant left by older corrupt files
    {
        result[0] = L'\0';  //key missing: empty string, caller keeps its default
        return FALSE;
    }

    lstrcpynW( result, szTemp, cch );
    return TRUE;
}

BOOL CNekoSettings::GetInt( LPCWSTR keyname, DWORD * result )
{
    WCHAR szValue[32];

    if( !GetString( keyname, szValue, sizeof(szValue) ) )
        return FALSE;

    if( szValue[0] == L'\0' )
        return FALSE;   //treat empty values as missing so the caller keeps its default

    *result = (DWORD)wcstoul( szValue, nullptr, 10 );
    return TRUE;
}

BOOL CNekoSettings::GetBool( LPCWSTR keyname, BOOL * result )
{
    DWORD dwValue;

    if( !GetInt( keyname, &dwValue ) )
        return FALSE;

    *result = (dwValue != 0);
    return TRUE;
}

BOOL CNekoSettings::SetString( LPCWSTR keyname, LPCWSTR value )
{
    if( m_szSection[0] == L'\0' )
        return FALSE;

    return ( WritePrivateProfileStringW( m_szSection, keyname, value, m_szIniPath ) != 0 );
}

BOOL CNekoSettings::SetInt( LPCWSTR keyname, DWORD value )
{
    WCHAR szValue[16];
    wsprintfW( szValue, L"%u", value );
    return SetString( keyname, szValue );
}

BOOL CNekoSettings::SetBool( LPCWSTR keyname, BOOL value )
{
    return SetString( keyname, value ? L"1" : L"0" );
}

BOOL CNekoSettings::DeleteValue( LPCWSTR keyname )
{
    if( m_szSection[0] == L'\0' )
        return FALSE;

    //passing NULL as the value removes the key from the section
    return ( WritePrivateProfileStringW( m_szSection, keyname, nullptr, m_szIniPath ) != 0 );
}

BOOL CNekoSettings::DeleteSection( LPCWSTR section )
{
    if( m_szSection[0] == L'\0' )
        return FALSE;

    return ( WritePrivateProfileSectionW( section, nullptr, m_szIniPath ) != 0 );
}

/* NekoCfgCleanupCorruptSections - sanitizes config.ini next to the executable.

   Corrupt files (written by older builds when the missing-key sentinel leaked
   into pet names) can contain:
     - sections whose names hold control characters (the 0x01-wrapped sentinel)
       or the bare sentinel text. The INI api can create such sections but
       WritePrivateProfileSectionW fails to match them for deletion, so the
       file has to be rewritten line by line instead;
     - entries whose values leak the sentinel;
     - repeated sections and repeated keys within one section.

   The file is rewritten only when garbage was actually removed; healthy files
   keep their exact bytes. All comparisons are ASCII byte matches, so ANSI and
   UTF-8 (with BOM) files are preserved untouched apart from the removed lines. */

#define CLEANUP_MAX_NAMES 128
#define CLEANUP_MAX_NAME  64

static const char s_szSentinelA[] = "NEKO_CFG_NOTFOUND";

static BOOL ContainsControlByte( const BYTE * p, ULONG cb )
{
    for( ULONG i = 0; i < cb; i++ )
        if( p[i] < 0x20 || p[i] == 0x7F )
            return TRUE;
    return FALSE;
}

static BOOL AsciiEqualsCI( const BYTE * p, ULONG cb, const char * sz )
{
    ULONG i;
    for( i = 0; i < cb && sz[i] != '\0'; i++ )
    {
        BYTE a = p[i], b = (BYTE)sz[i];
        if( a >= 'A' && a <= 'Z' ) a = (BYTE)(a - 'A' + 'a');
        if( b >= 'A' && b <= 'Z' ) b = (BYTE)(b - 'A' + 'a');
        if( a != b )
            return FALSE;
    }
    return (i == cb && sz[i] == '\0');
}

static BOOL FindAsciiCI( const BYTE * p, ULONG cb, const char * sz )
{
    ULONG n = 0;
    while( sz[n] != '\0' )
        n++;
    if( n == 0 || cb < n )
        return FALSE;
    for( ULONG i = 0; i + n <= cb; i++ )
        if( AsciiEqualsCI( p + i, n, sz ) )
            return TRUE;
    return FALSE;
}

static BOOL LookupName( char table[][CLEANUP_MAX_NAME], int count, const BYTE * p, ULONG cb )
{
    if( cb == 0 || cb >= CLEANUP_MAX_NAME )
        return FALSE;   //empty and overlong names are never deduplicated
    for( int i = 0; i < count; i++ )
        if( AsciiEqualsCI( p, cb, table[i] ) )
            return TRUE;
    return FALSE;
}

static void AddName( char table[][CLEANUP_MAX_NAME], int * pCount, const BYTE * p, ULONG cb )
{
    if( *pCount >= CLEANUP_MAX_NAMES || cb == 0 || cb >= CLEANUP_MAX_NAME )
        return;
    int n = (*pCount)++;
    for( ULONG i = 0; i < cb; i++ )
    {
        BYTE b = p[i];
        if( b >= 'A' && b <= 'Z' )
            b = (BYTE)(b - 'A' + 'a');
        table[n][i] = (char)b;
    }
    table[n][cb] = '\0';
}

BOOL NekoCfgCleanupCorruptSections( void )
{
    WCHAR szIniPath[MAX_PATH];
    if( !BuildIniPath( szIniPath, MAX_PATH ) )
        return FALSE;

    HANDLE hFile = CreateFileW( szIniPath, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr );
    if( hFile == INVALID_HANDLE_VALUE )
        return TRUE;    //no file yet: nothing to clean

    DWORD cbFile = GetFileSize( hFile, nullptr );
    if( cbFile == INVALID_FILE_SIZE || cbFile == 0 )
    {
        CloseHandle( hFile );
        return TRUE;
    }

    BYTE * pFile = new BYTE[cbFile];
    DWORD cbRead = 0;
    ReadFile( hFile, pFile, cbFile, &cbRead, nullptr );
    CloseHandle( hFile );
    if( cbRead != cbFile )
    {
        delete[] pFile;
        return TRUE;
    }

    BOOL fBom = (cbFile >= 3 && pFile[0] == 0xEF && pFile[1] == 0xBB && pFile[2] == 0xBF);
    const BYTE * pBody = pFile + (fBom ? 3 : 0);
    ULONG cbBody = cbFile - (fBom ? 3 : 0);
    BYTE * pOut = new BYTE[cbBody + 3];     //the output never grows past the input

    BOOL fChanged = FALSE;
    BOOL fSkipSection = FALSE;
    char seenKeys[CLEANUP_MAX_NAMES][CLEANUP_MAX_NAME];
    char seenSecs[CLEANUP_MAX_NAMES][CLEANUP_MAX_NAME];
    int nKeys = 0, nSecs = 0;

    ULONG iSrc = 0, iDst = 0;
    while( iSrc < cbBody )
    {
        ULONG lineStart = iSrc;
        while( iSrc < cbBody && pBody[iSrc] != '\n' )
            iSrc++;
        ULONG eolEnd = (iSrc < cbBody) ? iSrc + 1 : iSrc;   //including '\n'
        ULONG parseEnd = iSrc;                              //excluding '\r' and '\n'
        if( parseEnd > lineStart && pBody[parseEnd - 1] == '\r' )
            parseEnd--;

        const BYTE * pLine = pBody + lineStart;
        ULONG cbLine = parseEnd - lineStart;

        ULONG off = 0;
        while( off < cbLine && (pLine[off] == ' ' || pLine[off] == '\t') )
            off++;
        const BYTE * pT = pLine + off;
        ULONG cbT = cbLine - off;

        BOOL fKeep = TRUE;

        if( cbT > 0 && pT[0] == '[' )
        {
            //section header: keep the section or drop it with all its entries
            ULONG close = 0;
            BOOL fFound = FALSE;
            for( ULONG k = 1; k < cbT; k++ )
            {
                if( pT[k] == ']' )
                {
                    close = k;
                    fFound = TRUE;
                    break;
                }
            }
            if( fFound )
            {
                const BYTE * pName = pT + 1;
                ULONG cbName = close - 1;
                while( cbName > 0 && (pName[cbName-1] == ' ' || pName[cbName-1] == '\t') )
                    cbName--;
                while( cbName > 0 && (pName[0] == ' ' || pName[0] == '\t') )
                {
                    pName++;
                    cbName--;
                }

                if( ContainsControlByte( pName, cbName ) ||
                    AsciiEqualsCI( pName, cbName, s_szSentinelA ) ||
                    LookupName( seenSecs, nSecs, pName, cbName ) )
                {
                    fKeep = FALSE;
                    fSkipSection = TRUE;
                }
                else
                {
                    AddName( seenSecs, &nSecs, pName, cbName );
                    nKeys = 0;
                    fSkipSection = FALSE;
                }
            }
        }
        else if( fSkipSection )
        {
            fKeep = FALSE;  //an entry of a dropped section
        }
        else if( cbT > 0 && pT[0] != ';' && pT[0] != '#' )
        {
            //key line: drop leaked sentinel values and repeated keys
            ULONG eq = 0;
            BOOL fEq = FALSE;
            for( ULONG k = 0; k < cbT; k++ )
            {
                if( pT[k] == '=' )
                {
                    eq = k;
                    fEq = TRUE;
                    break;
                }
            }
            if( fEq )
            {
                ULONG cbKey = eq;
                while( cbKey > 0 && (pT[cbKey-1] == ' ' || pT[cbKey-1] == '\t') )
                    cbKey--;

                const BYTE * pVal = pT + eq + 1;
                ULONG cbVal = cbT - eq - 1;

                if( ContainsControlByte( pVal, cbVal ) ||
                    FindAsciiCI( pVal, cbVal, s_szSentinelA ) ||
                    LookupName( seenKeys, nKeys, pT, cbKey ) )
                {
                    fKeep = FALSE;
                }
                else
                {
                    AddName( seenKeys, &nKeys, pT, cbKey );
                }
            }
        }

        if( !fKeep )
            fChanged = TRUE;
        else
        {
            for( ULONG k = lineStart; k < eolEnd; k++ )
                pOut[iDst++] = pBody[k];
        }

        iSrc = eolEnd;
    }

    BOOL fOk = TRUE;
    if( fChanged )
    {
        HANDLE hOut = CreateFileW( szIniPath, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr );
        if( hOut != INVALID_HANDLE_VALUE )
        {
            DWORD cbWritten = 0;
            if( fBom )
            {
                const BYTE rgbBom[3] = { 0xEF, 0xBB, 0xBF };
                fOk = (WriteFile( hOut, rgbBom, 3, &cbWritten, nullptr ) != 0);
            }
            if( fOk )
                fOk = (WriteFile( hOut, pOut, iDst, &cbWritten, nullptr ) != 0);
            CloseHandle( hOut );
        }
        else
            fOk = FALSE;
    }

    delete[] pOut;
    delete[] pFile;
    return fOk;
}
