// Skins.h: shared built-in skin table.
//
// The table index is the skin number stored in config.ini ("Skin" key) and
// used by both NekoPet (pet context menu, icon loading) and NekoCFG (Display
// page combo box). Entries and their order must stay identical in both
// programs - they share this header to guarantee that.
//
// Each skin owns NEKO_SKIN_FRAMES consecutive ICON resource IDs starting at
// nIconFirst, in the oneko animation order documented in CNeko::LoadImages().

#ifndef _NEKO_SKINS_H_
#define _NEKO_SKINS_H_

#define NEKO_SKIN_FRAMES 32

struct NEKO_SKIN {
    LPCWSTR szName;     //display name (pet menu + config combo)
    int     nIconFirst; //first of NEKO_SKIN_FRAMES consecutive ICON resource IDs
};

static const NEKO_SKIN kNekoSkins[] = {
    //existing skins (icon resource IDs defined in resource.h)
    { L"Neko (cat)", 101 },  //IDI_CAT1_FIRST
    { L"Penguin",    143 },  //IDI_CAT2_FIRST
    //skins from the 2023 icon library (IDs 200..2631, 32 per skin)
    { L"ace", 200 },
    { L"air", 232 },
    { L"alien", 264 },
    { L"black", 296 },
    { L"black2", 328 },
    { L"blue", 360 },
    { L"blue-marine", 392 },
    { L"blue-tabby", 424 },
    { L"boobookitty", 456 },
    { L"brown-bsd-daemon", 488 },
    { L"brown-dog", 520 },
    { L"calico", 552 },
    { L"calico-tabby", 584 },
    { L"captain-goodnight", 616 },
    { L"caz", 648 },
    { L"coke-bottle", 680 },
    { L"colourful", 712 },
    { L"dave", 744 },
    { L"deedee", 776 },
    { L"dog", 808 },
    { L"doom", 840 },
    { L"earth", 872 },
    { L"face", 904 },
    { L"fancy", 936 },
    { L"ff3mog", 968 },
    { L"fire", 1000 },
    { L"ghetto", 1032 },
    { L"ghost", 1064 },
    { L"gray", 1096 },
    { L"green-ghost", 1128 },
    { L"holiday", 1160 },
    { L"jess", 1192 },
    { L"kina", 1224 },
    { L"kuramecha", 1256 },
    { L"lucky", 1288 },
    { L"lucy", 1320 },
    { L"lucy-dog", 1352 },
    { L"marmalade", 1384 },
    { L"mermaid", 1416 },
    { L"metroid", 1448 },
    { L"mike", 1480 },
    { L"mini", 1512 },
    { L"moka", 1544 },
    { L"multi", 1576 },
    { L"nekocool", 1608 },
    { L"neon", 1640 },
    { L"orange", 1672 },
    { L"pac-man", 1704 },
    { L"peach", 1736 },
    { L"penguin", 1768 },
    { L"penguin-2", 1800 },
    { L"pink", 1832 },
    { L"pink-nose-neko", 1864 },
    { L"rainbow", 1896 },
    { L"red-bsd-daemon", 1928 },
    { L"robot", 1960 },
    { L"rocket", 1992 },
    { L"rose", 2024 },
    { L"royal", 2056 },
    { L"silver", 2088 },
    { L"silversky", 2120 },
    { L"skunk", 2152 },
    { L"socks", 2184 },
    { L"sonic", 2216 },
    { L"spirit", 2248 },
    { L"spooky", 2280 },
    { L"tabby", 2312 },
    { L"tentacle", 2344 },
    { L"tie-fighter", 2376 },
    { L"turtle", 2408 },
    { L"usa", 2440 },
    { L"valentine", 2472 },
    { L"water", 2504 },
    { L"white", 2536 },
    { L"worms", 2568 },
    { L"zelda3", 2600 }
};

#define NEKO_NUM_SKINS (sizeof(kNekoSkins) / sizeof(kNekoSkins[0]))

#endif // _NEKO_SKINS_H_
