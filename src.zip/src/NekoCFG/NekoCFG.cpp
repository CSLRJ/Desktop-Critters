/****************
  NekoCFG

  Configuration
  program for
  Neko-ng

*****************/

#include "NekoCFG.h"
#include "NekoCFG_resource.h"
#include "NekoCFG_resource.hm"

/*************************************************************************************************/

LPCWSTR szWindowTitle = L"Configure Neko-ng";
LPCWSTR szDefaultName = L"Neko-ng (default)";
LPCWSTR szHelpFile = L"neko-ng.hlp";

/* help ID lookup table */
static DWORD dwHelpID[] = { 
    IDC_NAME,           HIDC_NAME, 
    IDC_NEW,            HIDC_NEW, 
    IDC_DELETE,         HIDC_DELETE,
    IDC_TASKBAR,        HIDC_TASKBAR, 
    IDC_ABOUT,          HIDC_ABOUT,
    IDOK,               HIDOK,
    IDCANCEL,           HIDCANCEL,
    IDC_APPLY,          HIDC_APPLY,
    IDC_HELP32,         HIDC_HELP,
    IDC_TABS,           HIDC_TABS,
    0,0
};

//global variables
HINSTANCE g_hInstance = nullptr;
HWND g_hWndNeko = nullptr;


//global settings
BOOL g_fShowTaskbar = TRUE;

// Apply-button dirty tracking: g_fDirty becomes TRUE on any data-changing
// user action; g_fInitialising guards against phantom MarkDirty during
// WM_INITDIALOG / MY_READSETTINGS (where programmatic control updates may
// emit WM_COMMAND / EN_CHANGE etc.).
static BOOL g_fDirty = FALSE;
BOOL g_fInitialising = FALSE;

//list of all cats
LPCATSETTINGS catSettings = nullptr;

//function forward declaration
void WINAPI WriteSettings();

static HICON kMainIcon = nullptr;
static HICON kSmallIcon = nullptr;

/*************************************************************************************************/

/* DeleteCatSettings - removes the given cat from the list */
BOOL WINAPI DeleteCatSettings( LPCATSETTINGS cat )
{
    cat->fDeleted = TRUE;
    return TRUE;
}

/* ExecuteNekoProcess - runs the main program *******************************/
static bool ExecuteNekoProcess() {
  // Locate NekoPet.exe next to this executable instead of relying on the
  // current working directory (which varies with how NekoCFG was started).
  WCHAR szExeDir[MAX_PATH + 1];
  DWORD dwLen = GetModuleFileNameW( nullptr, szExeDir, MAX_PATH );
  if( dwLen == 0 || dwLen >= MAX_PATH ) {
    MessageBoxW( nullptr, L"Neko Config was unable to locate its own executable.", L"NekoPet.exe Not Found", MB_ICONEXCLAMATION );
    return false;
  }
  // trim the string to the directory containing this EXE
  WCHAR * pSlash = szExeDir + lstrlenW( szExeDir );
  while( pSlash > szExeDir && *pSlash != L'\\' ) pSlash--;
  *pSlash = L'\0';
  // full path of the main program
  WCHAR szNekoPath[MAX_PATH + 16];
  wsprintfW( szNekoPath, L"%s\\NekoPet.exe", szExeDir );
  SHELLEXECUTEINFOW sei = {};
  sei.cbSize = sizeof(sei);
  sei.fMask = SEE_MASK_NOCLOSEPROCESS;
  sei.lpVerb = L"open";
  sei.lpFile = szNekoPath;
  sei.lpDirectory = szExeDir;
  sei.lpParameters = L"";
  sei.nShow = SW_SHOWNORMAL;
  if (!ShellExecuteExW(&sei) || !sei.hProcess) {
    MessageBoxW( nullptr, L"Neko Config was unable to start the main program\n'NekoPet.exe'\n\nMake sure that it is in the same folder as this program.", L"NekoPet.exe Not Found", MB_ICONEXCLAMATION );
    return false;
  }
  // Block until the new process has created its message queue and is idle —
  // only then is NekoPet's window registered and findable via FindWindowW.
  WaitForInputIdle( sei.hProcess, 5000 );
  CloseHandle( sei.hProcess );
  return true;
}

/* DlgProc_NewNeko - dialog box procedure to add a neko */
BOOL CALLBACK DlgProc_NewNeko( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_INITDIALOG:
        {
            //make sure the user isn't adding *too* many Nekos!
            LPCATSETTINGS cat = catSettings;
            int nCats = 0;
            while( cat )
            {
                if( cat->fDeleted == FALSE ) nCats++;
                cat = cat->next;
            }

            if( nCats > 5 )
            {
                WCHAR szBuffer[128];
                wsprintfW( szBuffer, L"You already have %d Nekos!\nAdding more is likely to slow down your computer - do you want to add one anyway?", nCats );
                if( IDNO == MessageBoxW( hDlg, szBuffer, L"Add Neko", MB_YESNO|MB_ICONQUESTION ) )
                {
                    EndDialog( hDlg, FALSE );
                    return TRUE;
                }
            }

            //initialise the text box
            SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_LIMITTEXT, IDC_NEWNEKONAME-2, 0 );

			//add some demo items
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Arthur" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Boris" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Kitty" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Lucy" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Garfield" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Tom" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Bast" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Ginger" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Bob" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Tabs" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Tigger" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"James" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Cooper" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Hey You" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Greebo" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Furball" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Sylvester" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Buffy" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Willow" );
			SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Sarah" );
			//SendDlgItemMessageW( hDlg, IDC_NEWNEKONAME, CB_ADDSTRING, 0, (LPARAM)L"Vicious Bastard" );
            break;
        }

        case WM_COMMAND:
            switch( LOWORD(wParam) )
            {
                case IDOK:
                {
                    WCHAR szName[MAX_NEKO_NAME];
                    GetDlgItemTextW( hDlg, IDC_NEWNEKONAME, szName, MAX_NEKO_NAME );
                    wchar_t* lpszPtr = szName;

                    //make sure it's not empty
                    if( lstrlenW( szName ) == 0 )
                    {
                        MessageBoxW( hDlg, L"Invalid Name: You must type a name", L"New Neko", MB_ICONINFORMATION );
                        return TRUE;
                    }

                    //make sure it only has letters, numbers and spaces in
                    while( lpszPtr && *lpszPtr != L'\0' )
                    {
                        if( !( iswalpha(*lpszPtr) || iswdigit(*lpszPtr) || *lpszPtr == L' ' ) )
                        {
                            MessageBoxW( hDlg, L"Invalid Name: Sorry - a name can only contain letters, numbers and spaces", L"Add Neko", MB_ICONINFORMATION );
                            return TRUE;
                        }
                        lpszPtr++;
                    }

                    //make sure it's unique
                    LPCATSETTINGS cat = catSettings;
                    while( cat )
                    {
                        if( !cat->fDeleted && (lstrcmpiW( cat->szName, szName ) == 0 || lstrcmpiW( cat->szName, szDefaultName ) == 0 ))
                        {
                            MessageBoxW( hDlg, L"Invalid Name: This neko already exists!", L"New Neko", MB_ICONINFORMATION );
                            return TRUE;
                        }
                        cat = cat->next;
                    }


                    //create a new neko
                    cat = new CATSETTINGS;
                    lstrcpyW( cat->szName, szName );

                    //set defaults (must match ReadCatSettings and NekoPet)
                    cat->uScale = 200;
                    cat->uSpeed = 16;
                    cat->uMouseSensitivity = 6;
                    cat->uAction = CHASE_MOUSE;
                    cat->uSkin = 0;

                    //link it in
                    cat->fDeleted = FALSE;
                    cat->next = catSettings;
                    catSettings = cat;

                    //add it to the list box & select it
                    int i = SendDlgItemMessageW( GetParent(hDlg), IDC_NAME, LB_ADDSTRING, 0, (LPARAM)szName );
                    SendDlgItemMessageW( GetParent(hDlg), IDC_NAME, LB_SETCURSEL, i, 0 );
                    PostMessageW( GetParent(hDlg), WM_COMMAND, MAKEWPARAM(IDC_NAME, CBN_SELCHANGE), 0 );

                    //close the dialog
                    EndDialog( hDlg, TRUE );
                    break;
                }

                case IDCANCEL:
                    EndDialog( hDlg, FALSE );
                    break;
            }
            break;

        default:
            return FALSE;
    }
    return TRUE;
}

/* DlgProc_About - dialog box procedure for about dialog */
static INT_PTR CALLBACK DlgProc_About( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
  UNREFERENCED_PARAMETER(lParam);
  switch (uMsg) {
    case WM_INITDIALOG:
      // Set icon in titlebar of about dialog
      static const HICON kAboutIcon = LoadIconW(g_hInstance, MAKEINTRESOURCEW(IDI_ABOUTICON));
      SendMessageW(hDlg, WM_SETICON, ICON_BIG, (LPARAM)kAboutIcon);
      SendMessageW(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)kAboutIcon);
      return TRUE;
    case WM_CLOSE:
      EndDialog( hDlg, TRUE );
      return TRUE;
    case WM_COMMAND:
      if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
        EndDialog(hDlg, LOWORD(wParam));
        return TRUE;
      }
      break;
    default:
      break;
  }

  return FALSE;
}

/* DlgProc_Config - dialog box procedure for configuration dialog */
BOOL CALLBACK DlgProc_Config( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_INITDIALOG:
        {
            g_fInitialising = TRUE;

            // Set icon in titlebar/taskbar
            SendMessageW(hDlg, WM_SETICON, ICON_BIG, (LPARAM)kMainIcon);
            SendMessageW(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)kSmallIcon);

            SendDlgItemMessageW( hDlg, IDC_TASKBAR, BM_SETCHECK, g_fShowTaskbar, 0 );

            LPCATSETTINGS cat = catSettings;
            while( cat )
            {
                if( !cat->fDeleted ) SendDlgItemMessageW( hDlg, IDC_NAME, LB_ADDSTRING, 0, ( cat->szName[0] == L'\0' ) ? (LPARAM)szDefaultName : (LPARAM)cat->szName );
                cat = cat->next;
            }
            //select the first entry; LB_SELECTSTRING would leave nothing
            //selected when the default entry is not in the list
            SendDlgItemMessageW( hDlg, IDC_NAME, LB_SETCURSEL, 0, 0 );
            EnableWindow( GetDlgItem( hDlg, IDC_DELETE ), FALSE );
            EnableWindow( GetDlgItem( hDlg, IDC_APPLY ), FALSE );

            InitialisePropertyDialog( GetDlgItem( hDlg, IDC_TABS ) );
            SendMessageW( hDlg, WM_COMMAND, MAKEWPARAM(IDC_NAME, LBN_SELCHANGE), 0 );

            g_fInitialising = FALSE;
            g_fDirty = FALSE;
            return TRUE;
        }

        case WM_MARKDIRTY:
            if( !g_fInitialising && !g_fDirty )
            {
                g_fDirty = TRUE;
                EnableWindow( GetDlgItem( hDlg, IDC_APPLY ), TRUE );
            }
            break;

        case WM_DESTROY:
            break;

        case WM_COMMAND:
            switch( LOWORD(wParam) )
            {
                case IDOK:
                    SetCursor( LoadCursorW( nullptr, IDC_WAIT ) );
                    g_fShowTaskbar = ( IsDlgButtonChecked( hDlg, IDC_TASKBAR ) == BST_CHECKED );
                    WriteSettings();
                    if( IsWindow( g_hWndNeko ) == FALSE ) g_hWndNeko = FindWindowW( szNekoClassName, szNekoWindowTitle );
                    SendMessageW( g_hWndNeko, MY_UPDATENEKO, 0, 0 );
                    SetCursor( LoadCursorW( nullptr, IDC_ARROW ) );
                    EndDialog( hDlg, TRUE );
                    break;

                case IDCANCEL:
                    EndDialog( hDlg, FALSE ); break;

                case IDC_APPLY:
                    SetCursor( LoadCursorW( nullptr, IDC_WAIT ) );
                    g_fShowTaskbar = ( IsDlgButtonChecked( hDlg, IDC_TASKBAR ) == BST_CHECKED );
                    WriteSettings();
                    if( IsWindow( g_hWndNeko ) == FALSE ) g_hWndNeko = FindWindowW( szNekoClassName, szNekoWindowTitle );
                    SendMessageW( g_hWndNeko, MY_UPDATENEKO, 0, 0 );
                    SetCursor( LoadCursorW( nullptr, IDC_ARROW ) );
                    g_fDirty = FALSE;
                    EnableWindow( GetDlgItem( hDlg, IDC_APPLY ), FALSE );
                    break;

                case IDC_ABOUT:
                    DialogBoxW( g_hInstance, MAKEINTRESOURCEW(IDD_ABOUTBOX), hDlg, (DLGPROC)DlgProc_About );
                    break;

                case IDC_TASKBAR:
                    PostMessageW( hDlg, WM_MARKDIRTY, 0, 0 );
                    break;

                case IDC_NEW:
                    if( DialogBoxW( g_hInstance, MAKEINTRESOURCEW(IDD_NEWNEKO), hDlg, (DLGPROC)DlgProc_NewNeko ) )
                        PostMessageW( hDlg, WM_MARKDIRTY, 0, 0 );
                    break;

                case IDC_DELETE:
                {
                    int iItem = SendDlgItemMessageW( hDlg, IDC_NAME, LB_GETCURSEL, 0, 0 );
                    WCHAR szDoomed[MAX_NEKO_NAME] = L"";

                    //get string
                    SendDlgItemMessageW( hDlg, IDC_NAME, LB_GETTEXT, iItem, (LPARAM)szDoomed );
                    if( lstrcmpW( szDoomed, szDefaultName ) == 0 ) szDoomed[0] = L'\0';

                    //find it in the settings list and continue
                    LPCATSETTINGS cat = catSettings;
                    while( cat )
                    {
                        if( !cat->fDeleted )
                            if( lstrcmpW( cat->szName, szDoomed ) == 0 ) break;

                        cat = cat->next;
                    }

                    if( cat )
                    {
                        //remove it from the list box
                        SendDlgItemMessageW( hDlg, IDC_NAME, LB_DELETESTRING, iItem, 0 );

                        //select another item
                        SendDlgItemMessageW( hDlg, IDC_NAME, LB_SETCURSEL, (iItem ? iItem-1 : 0), 0 );
                        SendMessageW( hDlg, WM_COMMAND, MAKEWPARAM(IDC_NAME,LBN_SELCHANGE), 0 );

                        //remove it from memory
                        if( DeleteCatSettings( cat ) == FALSE )
                            MessageBoxW( hDlg, L"Internal Error: Could not delete cat!", szWindowTitle, MB_ICONERROR );
                        else
                            PostMessageW( hDlg, WM_MARKDIRTY, 0, 0 );
                    }
                    else
                        MessageBoxW( hDlg, L"Internal Error: Dropped off the end of the cat list!", szWindowTitle, MB_ICONERROR );

                    break;
                }

                case IDC_HELP32:
                    WinHelpW( hDlg, szHelpFile, HELP_FINDER, 0 );
                    break;

                case IDC_NAME:
                    if( HIWORD(wParam) == LBN_SELCHANGE )
                    {
                        int iNew = SendDlgItemMessageW( hDlg, IDC_NAME, LB_GETCURSEL, 0, 0 );
                        WCHAR szNew[MAX_NEKO_NAME] = L"";

                        //get string and enable delete if it's not the default item (first)
                        SendDlgItemMessageW( hDlg, IDC_NAME, LB_GETTEXT, iNew, (LPARAM)szNew );
                        if( lstrcmpW( szNew, szDefaultName ) == 0 )
                        {
                            szNew[0] = L'\0';
                            EnableWindow( GetDlgItem( hDlg, IDC_DELETE ), FALSE );
                        }
                        else EnableWindow( GetDlgItem( hDlg, IDC_DELETE ), TRUE );

                        //the user has selected a different name - find it in the settings list and continue
                        LPCATSETTINGS cat = catSettings;
                        while( cat )
                        {
                            if( !cat->fDeleted )
                                if( lstrcmpW( cat->szName, szNew ) == 0 ) break;

                            cat = cat->next;
                        }

                        if( cat )
                            SetActiveCat( cat );
                        else
                            MessageBoxW( hDlg, L"Internal Error: Dropped off the end of the cat list!", szWindowTitle, MB_ICONERROR );
                    }
                    break;
                case IDC_OPENMAIN:
                  if( ExecuteNekoProcess() )
                  {
                    // neko_win32 is now running — refresh the cached HWND so a
                    // subsequent Apply / OK can push MY_UPDATENEKO to it.
                    g_hWndNeko = FindWindowW( szNekoClassName, szNekoWindowTitle );
                  }
                  break;
            }
            break;

        case WM_NOTIFY:
        {
            LPNMHDR nmhdr = (LPNMHDR)lParam;
            switch( nmhdr->idFrom )
            {
                case IDC_TABS:
                    if( nmhdr->code == TCN_SELCHANGE ) OnSelChanged( GetDlgItem( hDlg, IDC_TABS ) );
                    break;
            }
            break;
        }

        /* help stuff */
        case WM_HELP:
            if( ((LPHELPINFO)lParam)->iCtrlId != (-1) )
                WinHelpW( (HWND)((LPHELPINFO)lParam)->hItemHandle, szHelpFile, HELP_WM_HELP, (ULONG_PTR)dwHelpID );
            else
                return FALSE;
            break;

        case WM_CONTEXTMENU:
            WinHelpW( (HWND)wParam, szHelpFile, HELP_CONTEXTMENU, (ULONG_PTR)dwHelpID );
            break;

        default:
            return FALSE;
    }
    return TRUE;
}

/*************************************************************************************************/

/* WriteCatSetting - write a cat from the configuration file with the given cat settings block */
void WINAPI WriteCatSettings( LPCATSETTINGS cat, LPCWSTR szName )
{
    //see if this cat is flagged as deleted
    if( cat->fDeleted == TRUE )
    {
        //remove this cat's section from the configuration file
        if( lstrlenW( szName ) > 0 )
        {
            CNekoSettings NekoSettings( szNekoCfgSection );
            NekoSettings.DeleteSection( cat->szName );
        }
        else
            MessageBoxW( nullptr, L"Internal Error: Tried to delete default Neko!", 0, MB_TASKMODAL );
    }
    else
    {
        //build & open key
	    WCHAR szKey[1024];
	    lstrcpyW( szKey, szNekoCfgSection );
	    if( lstrlenW( szName ) > 0 )
	    {
		    lstrcatW( szKey, L"\\" );
		    lstrcatW( szKey, szName );
	    }

        //write cat to the configuration file
        CNekoSettings NekoSettings( szKey );

        //display
        NekoSettings.SetInt( szNekoScaleKey, cat->uScale );
        NekoSettings.SetInt( szNekoSkinKey, (cat->uSkin >= (DWORD)NEKO_NUM_SKINS) ? (DWORD)0 : cat->uSkin );

        //movement
        NekoSettings.SetInt( szNekoSpeedKey, cat->uSpeed );
        NekoSettings.SetInt( szNekoSenseKey, cat->uMouseSensitivity );

        //independence
        NekoSettings.SetInt( szNekoActionKey, (cat->uAction > RUN_AROUND) ? (DWORD)CHASE_MOUSE : cat->uAction );
    }
}


/* WriteSettings - writes all of the settings to the configuration file */
void WINAPI WriteSettings()
{
    //tell all dialogs to write what they've got so far into the data structure
    GetDialogSettings();

    //drop any bogus sections left behind by corrupt config files, so they
    //cannot survive another write cycle
    NekoCfgCleanupCorruptSections();

    //write global settings
    CNekoSettings NekoSettings( szNekoCfgSection );
    NekoSettings.SetBool( szNekoTaskbarKey, g_fShowTaskbar );
    
    int nNumCats = 0;
    LPCATSETTINGS cat = catSettings;
    while( cat )
    {
        //write this cat's settings
        WriteCatSettings( cat, cat->szName );

        //unlink it if it's been deleted, or write out the name index key if not
        if( cat->fDeleted == FALSE )
        {
            //build the key index
            WCHAR szSubKey[MAX_PATH];
            wsprintfW( szSubKey, L"%d", nNumCats );

            //write this cat's name to the configuration file
		    NekoSettings.SetString( szSubKey, cat->szName );

            //advance the list
            nNumCats++;
            cat = cat->next;
        }
        else
        {
            cat = cat->next;
        }
    }

    NekoSettings.SetInt( szNekoNumCatsKey, nNumCats );

    //the name index is renumbered 0..nNumCats-1 on every write; remove any
    //stale higher-numbered keys left behind when cats were deleted, so the
    //file never accumulates orphaned entries
    WCHAR szStaleKey[16];
    for( int i = nNumCats; i < NEKO_MAX_CATS; i++ )
    {
        wsprintfW( szStaleKey, L"%d", i );
        NekoSettings.DeleteValue( szStaleKey );
    }
}

/* ReadCatSetting - loads a cat from the configuration file into the given cat settings block */
void WINAPI ReadCatSettings( LPCATSETTINGS cat, LPCWSTR szName )
{
    lstrcpyW( cat->szName, szName );

    //set defaults (must match the NekoPet constructor defaults)
    cat->uScale = 200;
    cat->uSpeed = 16;
    cat->uMouseSensitivity = 6;
    cat->uAction = CHASE_MOUSE;
    cat->fDeleted = FALSE;
    cat->uSkin = 0;

    //build & open key
	WCHAR szKey[1024];
	lstrcpyW( szKey, szNekoCfgSection );
	if( lstrlenW( szName ) > 0 )
	{
		lstrcatW( szKey, L"\\" );
		lstrcatW( szKey, szName );
	}

    CNekoSettings NekoSettings( szKey );

    //display
    NekoSettings.GetInt( szNekoScaleKey, &cat->uScale );
    NekoSettings.GetInt( szNekoSkinKey, &cat->uSkin );

    //movement
    NekoSettings.GetInt( szNekoSpeedKey, &cat->uSpeed );
    NekoSettings.GetInt( szNekoSenseKey, &cat->uMouseSensitivity );

    //independence
    NekoSettings.GetInt( szNekoActionKey, &cat->uAction );

    //clamp every value to the same legal ranges NekoCFG's controls and
    //NekoPet enforce, so corrupt or hand-edited INI values cannot produce
    //unusable settings (e.g. an Action combo index that no entry matches)
    if( cat->uScale < MIN_SCALE ) cat->uScale = MIN_SCALE;
        else if( cat->uScale > MAX_SCALE ) cat->uScale = MAX_SCALE;
    if( cat->uSkin >= (DWORD)NEKO_NUM_SKINS ) cat->uSkin = 0;
    if( cat->uSpeed < MIN_SPEED ) cat->uSpeed = MIN_SPEED;
        else if( cat->uSpeed > MAX_SPEED ) cat->uSpeed = MAX_SPEED;
    if( cat->uMouseSensitivity < MIN_SENSE ) cat->uMouseSensitivity = MIN_SENSE;
        else if( cat->uMouseSensitivity > MAX_SENSE ) cat->uMouseSensitivity = MAX_SENSE;
    if( cat->uAction > RUN_AROUND ) cat->uAction = CHASE_MOUSE;
}

/* ReadSettings - reads all of the settings from the configuration file and creates the global settings array */
void WINAPI ReadSettings()
{
    LPCATSETTINGS cat;

    CNekoSettings * NekoSettings = new CNekoSettings( szNekoCfgSection );
    NekoSettings->GetBool( szNekoTaskbarKey, &g_fShowTaskbar );

    //load in new cats list (capped: a corrupt file must not be able to
    //make us build an oversized list)
    DWORD nNumCats = 0;
    NekoSettings->GetInt( szNekoNumCatsKey, &nNumCats );
    if( nNumCats > NEKO_MAX_CATS ) nNumCats = NEKO_MAX_CATS;

    if( nNumCats == 0 )
    {
        //the user hasn't run the config program, or there are no Nekos - use default
        cat = new CATSETTINGS;
        cat->next = nullptr;
        ReadCatSettings( cat, L"" );

        catSettings = cat;
    }
    else
    {
        for( DWORD i = 0; i < nNumCats; i++ )
        {
            //build the key index
            WCHAR szSubKey[MAX_PATH], szName[MAX_NEKO_NAME];
            wsprintfW( szSubKey, L"%d", i );
            szName[0] = L'\0';

            //load this cat's name; skip entries that are missing or invalid
            //(corrupt files must not produce bogus cat names)
            if( NekoSettings->GetString( szSubKey, szName, (MAX_NEKO_NAME-1) * sizeof(WCHAR) ) &&
                IsValidCatName( szName ) )
            {
                //skip duplicates so every name maps to a unique section
                BOOL fDup = FALSE;
                for( LPCATSETTINGS c = catSettings; c != nullptr; c = c->next )
                {
                    if( lstrcmpW( c->szName, szName ) == 0 ) { fDup = TRUE; break; }
                }
                if( fDup ) continue;

                //create a new setting for it and append it to the list,
                //keeping the config.ini numbering order (0..N-1) intact
                cat = new CATSETTINGS;
                cat->next = nullptr;
                ReadCatSettings( cat, szName );

                if( catSettings == nullptr )
                {
                    catSettings = cat;
                }
                else
                {
                    LPCATSETTINGS c = catSettings;
                    while( c->next != nullptr ) c = c->next;
                    c->next = cat;
                }
            }
        }

        if( catSettings == nullptr )
        {
            //no usable entries - fall back to the default anonymous cat
            cat = new CATSETTINGS;
            cat->next = nullptr;
            ReadCatSettings( cat, L"" );

            catSettings = cat;
        }
    }

    delete NekoSettings;
}

/* DeleteConfigList - deletes the list of settings from memory */
void WINAPI DeleteConfigList()
{
    LPCATSETTINGS cat = catSettings;
    while( catSettings )
    {
        cat = catSettings;
        catSettings = catSettings->next;
        delete cat;
    }
}


/* FindAndActivateOldInstance - activates the old instance of the configuration program
   if it has been loaded twice */
BOOL FindAndActivateOldInstance()
{
    HWND hWnd = FindWindowW( nullptr, szWindowTitle );
    if( hWnd )
    {
        OpenIcon(hWnd);
        SetForegroundWindow(hWnd);
        return TRUE;
    }

    return FALSE;
}

/* WinMain - main program start point */
int APIENTRY wWinMain(HINSTANCE hInstance,
                      HINSTANCE hPrevInstance,
                      LPWSTR lpCmdLine,
                      int iCmdShow) {
  UNREFERENCED_PARAMETER(hPrevInstance);

    //opt in to DPI awareness where supported (no-op on XP)
    EnableProcessDPIAwareness();

    //see if the configuration program is loaded already
    if( FindAndActivateOldInstance() ) return 0;

    //ensure the common control library is loaded
    InitCommonControls();

    //store the instance handle and find the Neko window
    g_hInstance = hInstance;
    g_hWndNeko = FindWindowW( szNekoClassName, szNekoWindowTitle );

  kMainIcon = LoadIconW(g_hInstance, MAKEINTRESOURCEW(IDI_APPICON));
  kSmallIcon = LoadIconW(g_hInstance, MAKEINTRESOURCEW(IDI_SMALL));

    //initialise program and display dialog
    ReadSettings();
    DialogBoxW( g_hInstance, MAKEINTRESOURCEW(IDD_CONFIG), nullptr, (DLGPROC)DlgProc_Config );
    DeleteConfigList();
    ShutdownPropertyDialog();
    return 0;
}
