#ifndef _NEKOCFG_H
#define _NEKOCFG_H

#include "../version.h"

#include <windows.h>
#include <commctrl.h>
#include <tchar.h>

#include <wctype.h>

#include "../NekoCommon.h"
#include "../NekoSettings.h"
#include "../Skins.h"

//structures
typedef struct tagTABINITDATA {
    LPCWSTR szTitle;
    UINT uIDDialog;
    DLGPROC lpfnDlgProc;
    UINT uIDIcon;
    HWND hDlg;
} TABINITDATA, *LPTABINITDATA;

typedef struct tagCATSETTINGS {
    WCHAR szName[MAX_NEKO_NAME];

    //display
    DWORD uScale;
    DWORD uSkin;

    //movement
    DWORD uSpeed;
    DWORD uMouseSensitivity;

    //independence
    DWORD uAction;

    //list items
    BOOL fDeleted;
    struct tagCATSETTINGS* next;

} CATSETTINGS, *LPCATSETTINGS;

//ranges for slider bars
#define MIN_SPEED 2
#define MAX_SPEED 48
#define MIN_SENSE 1
#define MAX_SENSE 64
#define MIN_SCALE 10
#define MAX_SCALE 400

//external functions
extern void WINAPI InitialisePropertyDialog( HWND hWnd );
extern void WINAPI ShutdownPropertyDialog();
extern void WINAPI OnSelChanged( HWND hWnd );
extern void WINAPI SetActiveCat( LPCATSETTINGS lpCat );
extern void WINAPI GetDialogSettings();

//external variables
extern HINSTANCE g_hInstance;
extern LPCWSTR szHelpFile;
extern BOOL g_fInitialising;

// Posted to the main config dialog by any tab page / main control whose value
// was just changed by the user. The main dlg proc sets a "dirty" flag and
// un-greys Apply. Gated on g_fInitialising to ignore programmatic updates
// during WM_INITDIALOG and MY_READSETTINGS.
#define WM_MARKDIRTY (WM_APP + 1)

#endif //_NEKOCFG_H
