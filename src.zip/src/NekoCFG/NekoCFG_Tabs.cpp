/* property sheet functions */

#include "NekoCFG.h"
#include "NekoCFG_resource.h"
#include "NekoCFG_resource.hm"


/* help ID lookup table */
static DWORD dwHelpID[] = { 
    IDC_SCALESLIDER,    HIDC_SCALESLIDER,
    IDC_SCALEDISPLAY,   HIDC_SCALEDISPLAY,
    IDC_SET100,         HIDC_SET100,

    IDC_SPEEDSLIDER,    HIDC_SPEEDSLIDER,
    IDC_SENSESLIDER,    HIDC_SENSESLIDER,

    IDC_ACTION,         HIDC_ACTION,
    IDC_ACTIONDESC,     HIDC_ACTIONDESC,

    IDC_FOOTPRINTS,     HIDC_FOOTPRINTS,
    0,0
};


/**************************************************************************************/

//cat settings
LPCATSETTINGS g_lpCurrentCat = nullptr;
#define MY_WRITESETTINGS (WM_USER+32)
#define MY_READSETTINGS  (WM_USER+33)

// Post WM_MARKDIRTY to the parent (main config dialog) whenever a tab-page
// control's value is changed by the user. g_fInitialising gates out the
// storm of phantom WM_COMMAND / EN_CHANGE events emitted while we populate
// controls during WM_INITDIALOG / MY_READSETTINGS.
static inline void MarkDirty( HWND hPage )
{
    PostMessageW( GetParent(hPage), WM_MARKDIRTY, 0, 0 );
}

/**************************************************************************************/
//tab control data

#define NUM_PAGES 4
BOOL CALLBACK PropPage_Display( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam );
BOOL CALLBACK PropPage_Movement( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam );
BOOL CALLBACK PropPage_Independence( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam );
BOOL CALLBACK PropPage_Effects( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam );
TABINITDATA tibTabs[NUM_PAGES] = {
    { L"Display",      IDD_DISPLAY,      (DLGPROC)PropPage_Display,      IDI_TAB_DISPLAY,      nullptr },
    { L"Movement",     IDD_MOVEMENT,     (DLGPROC)PropPage_Movement,     IDI_TAB_MOVEMENT,     nullptr },
    { L"Behavior",     IDD_INDEPENDENCE, (DLGPROC)PropPage_Independence, IDI_TAB_INDEPENDENCE, nullptr },
    { L"Effects",      IDD_EFFECTS,      (DLGPROC)PropPage_Effects,      IDI_TAB_EFFECTS,      nullptr },
};

HWND g_hDlgDisplay = nullptr;      //current child dialog
HWND g_hWndTab = nullptr;          //tab control
RECT g_rcTabStart;              //offset in dialog to draw tab pages

HIMAGELIST g_himgTabIcons = nullptr;

/**************************************************************************************/


/* InitialisePropertyDialog - loads all of the property sheet pages into the property sheet control */
void WINAPI InitialisePropertyDialog( HWND hWnd )
{
    int i;

    //create the image list
    g_himgTabIcons = ImageList_Create( 16, 16, ILC_COLOR4|ILC_MASK, NUM_PAGES, 0 );
    for( i = 0; i < NUM_PAGES; i++ )
    {
        HICON hIcon = (HICON)LoadImageW( g_hInstance, MAKEINTRESOURCEW(tibTabs[i].uIDIcon), IMAGE_ICON, 0, 0, LR_DEFAULTSIZE );
        tibTabs[i].uIDIcon = ImageList_AddIcon( g_himgTabIcons, hIcon );
        DestroyIcon( hIcon );
    }
    TabCtrl_SetImageList( hWnd, g_himgTabIcons );


    //insert tabs for each of the dialog items and create the (hidden) dialog
    TCITEMW tie;
    tie.mask = TCIF_TEXT | TCIF_IMAGE;
    for( i = 0; i < NUM_PAGES; i++ )
    {
        tie.iImage = tibTabs[i].uIDIcon;
        tie.pszText = (LPWSTR)tibTabs[i].szTitle;
        SendMessageW( hWnd, TCM_INSERTITEMW, (WPARAM)i, (LPARAM)&tie );

        tibTabs[i].hDlg = CreateDialogW( g_hInstance, MAKEINTRESOURCEW(tibTabs[i].uIDDialog), GetParent(hWnd), tibTabs[i].lpfnDlgProc );
    }

    //calculate where to stick each dialog
    GetWindowRect( hWnd, &g_rcTabStart );
    ScreenToClient( GetParent(hWnd), (LPPOINT)&g_rcTabStart.left );
    ScreenToClient( GetParent(hWnd), (LPPOINT)&g_rcTabStart.right );
    g_rcTabStart.top += 42;
    g_rcTabStart.left += 3;

    //store the handle and show the first page
    g_hWndTab = hWnd;
    OnSelChanged( hWnd );
}

/* ShutdownPropertyDialog - releases any resources owned by the propery sheet */
void WINAPI ShutdownPropertyDialog()
{
    ImageList_Destroy( g_himgTabIcons );
}

/* OnTabSelection - updates the tabs when one is selected */
void WINAPI OnSelChanged( HWND hWnd ) 
{ 
    int iSel = TabCtrl_GetCurSel( hWnd ); 
 
    //destroy the current child dialog box, if any. 
    if( g_hDlgDisplay != nullptr) ShowWindow( g_hDlgDisplay, SW_HIDE ); 
 
    //create the new child dialog box. 
    g_hDlgDisplay = tibTabs[iSel].hDlg;
    ShowWindow( g_hDlgDisplay, SW_SHOW );
    
}

/* SetActiveCat - selects which cat to configure */
void WINAPI SetActiveCat( LPCATSETTINGS lpCat )
{
    GetDialogSettings();
    g_lpCurrentCat = lpCat;
    // Programmatic updates from MY_READSETTINGS would otherwise be indistinguishable
    // from user edits — guard the broadcast so no phantom MarkDirty is posted.
    g_fInitialising = TRUE;
    for( int i = 0; i < NUM_PAGES; i++ ) SendMessageW( tibTabs[i].hDlg, MY_READSETTINGS, 0, 0 );
    g_fInitialising = FALSE;
}

/* GetDialogSettings - causes all property pages to write their settings into the data structure */
void WINAPI GetDialogSettings()
{
    if( g_lpCurrentCat ) 
        for( int i = 0; i < NUM_PAGES; i++ ) SendMessageW( tibTabs[i].hDlg, MY_WRITESETTINGS, 0, 0 );
}

/**************************************************************************************/

/* PropPage_Display - message processsing function for the 'display' property page */
BOOL CALLBACK PropPage_Display( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_INITDIALOG:
            SendDlgItemMessageW( hPage, IDC_SCALESLIDER, TBM_SETRANGE, FALSE, MAKELPARAM(MIN_SCALE/10,MAX_SCALE/10) );

            //skin list: entries and their order must match the NekoPet
            //context menu exactly (skin index = combo index)
            for( int s = 0; s < (int)NEKO_NUM_SKINS; s++ )
                SendDlgItemMessageW( hPage, IDC_SKIN, CB_ADDSTRING, 0, (LPARAM)kNekoSkins[s].szName );
            break;

        case MY_WRITESETTINGS:
            g_lpCurrentCat->uScale = SendDlgItemMessageW( hPage, IDC_SCALESLIDER, TBM_GETPOS, 0, 0 ) * 10;
        {
            //CB_GETCURSEL returns LB_ERR (-1) when nothing is selected;
            //keep the previous skin instead of writing a bogus index
            DWORD dwSel = (DWORD)SendDlgItemMessageW( hPage, IDC_SKIN, CB_GETCURSEL, 0, 0 );
            if( dwSel != (DWORD)CB_ERR )
                g_lpCurrentCat->uSkin = (dwSel >= (DWORD)NEKO_NUM_SKINS) ? 0 : dwSel;
        }
            break;

        case MY_READSETTINGS:
            SendDlgItemMessageW( hPage, IDC_SCALESLIDER, TBM_SETPOS, TRUE, g_lpCurrentCat->uScale / 10 );
            SendDlgItemMessageW( hPage, IDC_SKIN, CB_SETCURSEL, (g_lpCurrentCat->uSkin >= (DWORD)NEKO_NUM_SKINS) ? 0 : g_lpCurrentCat->uSkin, 0 );
            SendMessageW( hPage, WM_HSCROLL, 0, 0 );
            break;

        case WM_HSCROLL:
        {
            //update the % indicator
            WCHAR szBuffer[32];
            wsprintfW( szBuffer, L"%d%%", (int)(SendDlgItemMessageW( hPage, IDC_SCALESLIDER, TBM_GETPOS, 0, 0 ) * 10) );
            SetDlgItemTextW( hPage, IDC_SCALEDISPLAY, szBuffer );
            MarkDirty( hPage );
            break;
        }

        case WM_COMMAND:

            switch( LOWORD(wParam) )
            {
                case IDC_SET100:
                    SendDlgItemMessageW( hPage, IDC_SCALESLIDER, TBM_SETPOS, TRUE, 10 );
                    SendMessageW( hPage, WM_HSCROLL, 0, 0 );
                    break;

                case IDC_SKIN:
                    if( HIWORD(wParam) == CBN_SELCHANGE )
                        MarkDirty( hPage );
                    break;
            }
            break;

        case WM_SHOWWINDOW:
            if( wParam ) SetWindowPos( hPage, HWND_TOP, g_rcTabStart.left, g_rcTabStart.top, 0, 0, SWP_NOSIZE );
            break;

        /* help stuff */
        case WM_HELP:
            if( ((LPHELPINFO)lParam)->iCtrlId != (-1) )
                WinHelpW( (HWND)((LPHELPINFO)lParam)->hItemHandle, szHelpFile, HELP_WM_HELP, (ULONG_PTR)dwHelpID );
            else
                return FALSE;
            break;

        case WM_CONTEXTMENU:
            WinHelpW( (HWND)wParam, szHelpFile, HELP_CONTEXTMENU, (ULONG_PTR)dwHelpID );
            break;

        default:
            return FALSE;
    }
    return TRUE;
}


/* PropPage_Movement - message processsing function for the 'movement' property page */
BOOL CALLBACK PropPage_Movement( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_INITDIALOG:
            SendDlgItemMessageW( hPage, IDC_SPEEDSLIDER, TBM_SETRANGE, FALSE, MAKELPARAM(MIN_SPEED,MAX_SPEED) );
            SendDlgItemMessageW( hPage, IDC_SENSESLIDER, TBM_SETRANGE, FALSE, MAKELPARAM(MIN_SENSE,MAX_SENSE) );
            break;

        case MY_WRITESETTINGS:
            g_lpCurrentCat->uSpeed = SendDlgItemMessageW( hPage, IDC_SPEEDSLIDER, TBM_GETPOS, 0, 0 );
            g_lpCurrentCat->uMouseSensitivity = MAX_SENSE - SendDlgItemMessageW( hPage, IDC_SENSESLIDER, TBM_GETPOS, 0, 0 );
            break;

        case MY_READSETTINGS:
            SendDlgItemMessageW( hPage, IDC_SPEEDSLIDER, TBM_SETPOS, TRUE, g_lpCurrentCat->uSpeed );
            SendDlgItemMessageW( hPage, IDC_SENSESLIDER, TBM_SETPOS, TRUE, MAX_SENSE - g_lpCurrentCat->uMouseSensitivity );
            break;

        case WM_HSCROLL:
            MarkDirty( hPage );
            break;

        case WM_SHOWWINDOW:
            if( wParam ) SetWindowPos( hPage, HWND_TOP, g_rcTabStart.left, g_rcTabStart.top, 0, 0, SWP_NOSIZE );
            break;

        /* help stuff */
        case WM_HELP:
            if( ((LPHELPINFO)lParam)->iCtrlId != (-1) )
                WinHelpW( (HWND)((LPHELPINFO)lParam)->hItemHandle, szHelpFile, HELP_WM_HELP, (ULONG_PTR)dwHelpID );
            else
                return FALSE;
            break;

        case WM_CONTEXTMENU:
            WinHelpW( (HWND)wParam, szHelpFile, HELP_CONTEXTMENU, (ULONG_PTR)dwHelpID );
            break;

        default:
            return FALSE;
    }
    return TRUE;
}

/* PropPage_Independence - message processsing function for the 'independence' property page */
BOOL CALLBACK PropPage_Independence( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_INITDIALOG:
            SendDlgItemMessageW( hPage, IDC_ACTION, CB_ADDSTRING, 0, (LPARAM)L"Chase the mouse (default)" );
            SendDlgItemMessageW( hPage, IDC_ACTION, CB_ADDSTRING, 0, (LPARAM)L"Run away from the mouse");
            SendDlgItemMessageW( hPage, IDC_ACTION, CB_ADDSTRING, 0, (LPARAM)L"Run around randomly");
            SendDlgItemMessageW( hPage, IDC_ACTION, CB_ADDSTRING, 0, (LPARAM)L"Pace around the screen");
            SendDlgItemMessageW( hPage, IDC_ACTION, CB_ADDSTRING, 0, (LPARAM)L"Run around the screen");
            break;

        case MY_WRITESETTINGS:
        {
            //CB_GETCURSEL returns LB_ERR (-1) when nothing is selected;
            //keep the previous action instead of writing a bogus index
            DWORD dwSel = (DWORD)SendDlgItemMessageW( hPage, IDC_ACTION, CB_GETCURSEL, 0, 0 );
            if( dwSel != (DWORD)CB_ERR )
                g_lpCurrentCat->uAction = (dwSel > RUN_AROUND) ? (DWORD)CHASE_MOUSE : dwSel;
        }
            break;

        case MY_READSETTINGS:
        {
            DWORD dwAct = (g_lpCurrentCat->uAction > RUN_AROUND) ? (DWORD)CHASE_MOUSE : g_lpCurrentCat->uAction;
            SendDlgItemMessageW( hPage, IDC_ACTION, CB_SETCURSEL, dwAct, 0 );
            SendMessageW( hPage, WM_COMMAND, MAKEWPARAM(IDC_ACTION, CBN_SELCHANGE), 0 );
        }
            break;

        case WM_SHOWWINDOW:
            if( wParam ) SetWindowPos( hPage, HWND_TOP, g_rcTabStart.left, g_rcTabStart.top, 0, 0, SWP_NOSIZE );
            break;

        case WM_COMMAND:
            switch( LOWORD(wParam) )
            {
                case IDC_ACTION:
                    if( HIWORD(wParam) == CBN_SELCHANGE )
                    {
                        LPCWSTR szActionDesc[] = {
                            L"Neko will follow the mouse cursor wherever it goes",
                            L"Neko will run away when the mouse cursor gets too near, and sleep when it isn't near",
                            L"Neko will run to a random spot on the desktop, sleep for a while, and then continue running around",
                            L"Neko will run around the outside of the desktop",
                            L"Neko will run around the desktop, without stopping"
                        };

                        SetDlgItemTextW( hPage, IDC_ACTIONDESC, szActionDesc[SendDlgItemMessageW( hPage, IDC_ACTION, CB_GETCURSEL, 0, 0 )] );
                        MarkDirty( hPage );
                    }
                    break;
            }
            break;

        /* help stuff */
        case WM_HELP:
            if( ((LPHELPINFO)lParam)->iCtrlId != (-1) )
                WinHelpW( (HWND)((LPHELPINFO)lParam)->hItemHandle, szHelpFile, HELP_WM_HELP, (ULONG_PTR)dwHelpID );
            else
                return FALSE;
            break;

        case WM_CONTEXTMENU:
            WinHelpW( (HWND)wParam, szHelpFile, HELP_CONTEXTMENU, (ULONG_PTR)dwHelpID );
            break;

        default:
            return FALSE;
    }
    return TRUE;
}




/* PropPage_Effects - message processsing function for the 'effects' property page */
BOOL CALLBACK PropPage_Effects( HWND hPage, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case MY_WRITESETTINGS:
            g_lpCurrentCat->bFootprints = IsDlgButtonChecked( hPage, IDC_FOOTPRINTS );
            break;

        case MY_READSETTINGS:
			CheckDlgButton( hPage, IDC_FOOTPRINTS, g_lpCurrentCat->bFootprints );
            break;

        case WM_COMMAND:

            switch( LOWORD(wParam) )
            {
                case IDC_FOOTPRINTS:
                    MarkDirty( hPage );
                    break;
            }
            break;

        case WM_SHOWWINDOW:
            if( wParam ) SetWindowPos( hPage, HWND_TOP, g_rcTabStart.left, g_rcTabStart.top, 0, 0, SWP_NOSIZE );
            break;

        /* help stuff */
        case WM_HELP:
            if( ((LPHELPINFO)lParam)->iCtrlId != (-1) )
                WinHelpW( (HWND)((LPHELPINFO)lParam)->hItemHandle, szHelpFile, HELP_WM_HELP, (ULONG_PTR)dwHelpID );
            else
                return FALSE;
            break;

        case WM_CONTEXTMENU:
            WinHelpW( (HWND)wParam, szHelpFile, HELP_CONTEXTMENU, (ULONG_PTR)dwHelpID );
            break;

        default:
            return FALSE;
    }
    return TRUE;
}
