// AlwaysOnTopPet.h: interface for the CAlwaysOnTopPet class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _NEKO_ALWAYS_ON_TOP_PET_H_
#define _NEKO_ALWAYS_ON_TOP_PET_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Pet.h"

class CAlwaysOnTopPet : virtual public CPet  
{
public:
	virtual void MoveTo( int nNewX, int nNewY );
	virtual void SetImage( int nImage );
	virtual void SetImageAndMoveTo( int nImage, int nNewX, int nNewY );
	virtual void SetImages( SkinIconTable* pTable );
	CAlwaysOnTopPet();
	virtual ~CAlwaysOnTopPet();

    virtual void DrawOnTarget( int x, int y, HICON hIcon );

    //scale change: refresh region handles and window size
    virtual void OnScaleChanged();

    //work area: the monitor this pet's window is on (multi-monitor aware)
    virtual RECT GetWorkArea();

    //virtual callback functions - these can all be overridden to perform different actions
    //depending on the various mouse clicks. Note: CAlwaysOnTopPet::OnLButtonDown() handles
    //the dragging - if this is overridden, OnLButtonUp is not called.

    virtual void OnLButtonDown();   //implementation is in .cpp file
    virtual void OnLButtonUp()      {};
    virtual void OnLButtonDblClk()  {};
    virtual void OnMButtonDown()    {};
    virtual void OnMButtonUp()      {};
    virtual void OnMButtonDblClk()  {};
    virtual void OnRButtonDown()    {};
    virtual void OnRButtonUp()      {};
    virtual void OnRButtonDblClk()  {};

    //class information functions
    inline BOOL IsDragging() { return m_fBeingDragged; };

    //fall-pending flag (set when the pet is dropped above the work area floor)
    virtual BOOL IsFallPending()     { return m_fFallPending; }
    virtual void ClearFallPending()  { m_fFallPending = FALSE; }

    //context menu hook: set once by Neko98.cpp; invoked from WM_RBUTTONDOWN
    static void (*s_pfnContextMenu)(CAlwaysOnTopPet*);

protected:
	HWND m_hWndOnTop;
	BOOL m_fBeingDragged;
	BOOL m_fFallPending;
	HRGN IconMaskToRegion( HICON hIcon );
	virtual void DestroyImages();
	HRGN* m_hRgns;                //borrowed from m_pRegionSet, do not free here
	SkinRegionSet* m_pRegionSet;  //shared, cache-owned window region set
	virtual void Erase();
	virtual void Draw( int nImage );

private:
	void DestroyRegions();
	static BOOL m_fRegisteredClass;

friend 
	LRESULT CALLBACK WndProc_OnTop( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

	
};

#endif // _NEKO_ALWAYS_ON_TOP_PET_H_
