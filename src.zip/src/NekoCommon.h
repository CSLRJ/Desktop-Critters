/************************************

   Common Definitions header

   Contains definitions used by both
   neko_win32 and neko_cfg applications

 *************************************/

#ifndef _NEKO_COMMON_H_
#define _NEKO_COMMON_H_

//this header must be self-sufficient: it is included before windows.h by
//some translation units (eg. Neko.cpp), so pull in windows.h here
#include <windows.h>

//class & window names
#define szNekoClassName   L"Neko98Class"
#define szNekoWindowTitle L"Neko-ng"

//section name in config.ini for Neko's global settings
#define szNekoCfgSection  L"Neko-ng"

//sub-key names
#define szNekoTaskbarKey      L"Taskbar Icon"

#define szNekoSpeedKey        L"Speed"
#define szNekoSenseKey        L"Sensitivity"
#define szNekoScaleKey        L"Size"
#define szNekoActionKey       L"Action"
#define szNekoNumCatsKey      L"NumNekos"
#define szNekoSkinKey         L"Skin"


//identifiers for different Neko actions
#define CHASE_MOUSE           0
#define RUN_AWAY_FROM_MOUSE   1
#define RUN_AROUND_RANDOMLY   2
#define PACE_AROUND_SCREEN    3
#define RUN_AROUND            4


//message sent from NekoCFG to Neko to signal settings have changed
#define MY_UPDATENEKO (WM_USER+33)

//enable DPI awareness when the API is available (Vista and later); on older
//systems (XP) the call is skipped and default DPI virtualization applies,
//which keeps 96-DPI rendering intact. Integer scale factors (100%/200% etc.)
//via the pet menu remain the preferred way to enlarge the pet on high-DPI
//displays. Must be called before any window is created.
inline void EnableProcessDPIAwareness()
{
	HMODULE hUser32 = GetModuleHandleW( L"user32.dll" );
	if( hUser32 != nullptr )
	{
		typedef BOOL (WINAPI *PFN_SetProcessDPIAware)();
		PFN_SetProcessDPIAware pfn = (PFN_SetProcessDPIAware)GetProcAddress( hUser32, "SetProcessDPIAware" );
		if( pfn != nullptr )
			pfn();
	}
}

//maximum length of a neko 'Name'
#define MAX_NEKO_NAME (64)

//maximum number of cats (guards against oversized lists in corrupt configs)
#define NEKO_MAX_CATS (32)

//a valid cat name must not contain control characters or INI structure
//delimiters ('[' ']' ';' '='); an empty name is allowed (anonymous cat)
inline BOOL IsValidCatName( LPCWSTR name )
{
    if( name == nullptr )
        return FALSE;

    for( LPCWSTR p = name; *p != L'\0'; p++ )
    {
        WCHAR c = *p;
        if( c < L' ' || c == L'[' || c == L']' || c == L';' || c == L'=' )
            return FALSE;
    }
    return TRUE;
}

#endif // _NEKO_COMMON_H_
