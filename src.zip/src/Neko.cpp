// Neko.cpp: implementation of the CNeko class.
//
//////////////////////////////////////////////////////////////////////

#include "NekoCommon.h"
#include "NekoSettings.h"
#include "Neko.h"
#include "resource.h"
#include "Skins.h"

//maths calculations
#define g_dSinPiPer8        0.3826834323651  // sin [pi/8]
#define g_dSinPiPer8Times3  0.9238795325113  // sin ( [pi/8] x 3 )

//misc. constants
#define MAX_TICK        9999 //Odd Only

//animation control constants
#define STOP_TIME      4
#define WASH_TIME      10
#define SCRATCH_TIME   4
#define YAWN_TIME      3
#define AWAKE_TIME     3
#define CLAW_TIME      10

//external system variable
extern HINSTANCE g_hInstance;


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNeko::CNeko( LPCWSTR lpszName )
{
	//store pet
	m_pPet = nullptr;

    //plug icons into animation table
	m_nAnimation[STOP][0]	 = 28;      m_nAnimation[STOP][1] =	    28;
	m_nAnimation[WASH][0]	 = 25;      m_nAnimation[WASH][1] =	    28;
	m_nAnimation[SCRATCH][0] = 26;      m_nAnimation[SCRATCH][1] =  27;
	m_nAnimation[YAWN][0]	 = 29;      m_nAnimation[YAWN][1] =	    29;
	m_nAnimation[SLEEP][0]	 = 30;      m_nAnimation[SLEEP][1] =	31;
	m_nAnimation[AWAKE][0]	 = 0;	    m_nAnimation[AWAKE][1] =	0;
	m_nAnimation[U_MOVE][0]  = 1;	    m_nAnimation[U_MOVE][1] =	2;
	m_nAnimation[D_MOVE][0]  = 9;	    m_nAnimation[D_MOVE][1] =	10;
	m_nAnimation[L_MOVE][0]  = 13;      m_nAnimation[L_MOVE][1] =	14;
	m_nAnimation[R_MOVE][0]  = 5;	    m_nAnimation[R_MOVE][1] =	6;
	m_nAnimation[UL_MOVE][0] = 15;      m_nAnimation[UL_MOVE][1] =  16;
	m_nAnimation[UR_MOVE][0] = 3;	    m_nAnimation[UR_MOVE][1] =  4;
	m_nAnimation[DL_MOVE][0] = 11;      m_nAnimation[DL_MOVE][1] =  12;
	m_nAnimation[DR_MOVE][0] = 7;	    m_nAnimation[DR_MOVE][1] =  8;
	m_nAnimation[U_CLAW][0]  = 17;      m_nAnimation[U_CLAW][1] =	18;
	m_nAnimation[D_CLAW][0]  = 23;      m_nAnimation[D_CLAW][1] =	24;
	m_nAnimation[L_CLAW][0]  = 21;      m_nAnimation[L_CLAW][1] =	22;
	m_nAnimation[R_CLAW][0]  = 19;      m_nAnimation[R_CLAW][1] =	20;
	//falling: the pet is airborne but visually calm - the same settled,
	//sitting frame as STOP. Physics (gravity / bounce) runs independently.
	m_nAnimation[FALL][0]	 = 28;      m_nAnimation[FALL][1] =	    28;

    //set variables
	m_nDX = m_nDY = 0;

    //defend against bogus names (corrupt config): invalid names become
    //the anonymous default cat
    if( !IsValidCatName( lpszName ) ) lpszName = L"";
	lstrcpynW( m_szName, lpszName, MAX_NEKO_NAME );
    m_dwSpeed = 16;
    m_dwIdleSpace = 6;
    m_Action = CHASE_MOUSE;
    m_nActionCount = 0;
    *m_szLibname = L'\0';
    m_bFootprints = FALSE;
    m_nSkin = 0;
    m_fFalling = FALSE;
    m_nFallVel = 0;

    m_dwScale = 200;

	//build configuration section name
	WCHAR szKey[1024];
	lstrcpyW( szKey, szNekoCfgSection );
	if( lstrlenW( m_szName ) > 0 )
	{
		lstrcatW( szKey, L"\\" );
		lstrcatW( szKey, m_szName );
	}

	//load configuration
    CNekoSettings NekoSettings( szKey, (lstrlenW(m_szName) == 0) );
	if( NekoSettings.IsOpen() )
	{
		//load in all of the settings
		NekoSettings.GetInt( szNekoScaleKey,		&m_dwScale );
		NekoSettings.GetInt( szNekoSpeedKey,		&m_dwSpeed );
		NekoSettings.GetInt( szNekoSenseKey,		&m_dwIdleSpace );
        NekoSettings.GetBool( szNekoFootprintKey,   &m_bFootprints );

        DWORD dwSkin = 0;
        NekoSettings.GetInt( szNekoSkinKey, &dwSkin );
        //invalid skin indices fall back to the default skin, matching the
        //clamp NekoCFG applies in ReadCatSettings
        m_nSkin = (dwSkin >= NEKO_NUM_SKINS) ? 0 : (int)dwSkin;

        DWORD dwAction = m_Action;
        NekoSettings.GetInt( szNekoActionKey, &dwAction );
        m_Action = (int)dwAction;

        //clamp to the same legal ranges NekoCFG enforces, so hand-edited
        //or corrupt values cannot put the pet into an unusable state
        if( m_dwScale < 10 ) m_dwScale = 10;      else if( m_dwScale > 400 ) m_dwScale = 400;
        if( m_dwSpeed < 2 )  m_dwSpeed = 2;       else if( m_dwSpeed > 48 )  m_dwSpeed = 48;
        if( m_dwIdleSpace < 1 ) m_dwIdleSpace = 1; else if( m_dwIdleSpace > 64 ) m_dwIdleSpace = 64;
        if( m_Action < 0 )  m_Action = 0;         else if( m_Action > RUN_AROUND ) m_Action = RUN_AROUND;


        //create the pet
    m_pPet = new CAlwaysOnTopPet();
	}
    else
    {
        //configuration didn't open... create the pet anyway
        m_pPet = new CAlwaysOnTopPet();
    }

    //initialse footprint icons
    for( int i = 0; i < 8; i++ ) m_hIconFootprints[i] = nullptr;

    //apply scaling
    m_pPet->SetScale( ((float)m_dwScale / 100.0f ) );

	//load the images from the built-in icon library (this executable)
	GetModuleFileNameW( nullptr, m_szLibname, MAX_PATH );
	BOOL fLoadProblems = !LoadImages();

	/* FIXME:

		It appears that Windows offers no support for ExtractIcon
		on icons that are not 32x32 - this means that all icon
		libraries selected by the user to use will have their icons
		scaled down to 32x32. I have tried the following:

        1) Used LoadLibrary() to load the icon library chosen. This
		   worked on some, but not all. I then used LoadLibraryEx() 
		   and passed it the 'don't call DllMain' flags. This caused
		   the libraries that weren't working to work, and vice-versa.

		2) After LoadLibrary(), attempting to load all resource IDs
		   until 32 valid icons were loaded. This nearly worked, but
		   took ages and was therefor unacceptable. It also failed
		   with LoadLibrary() as in 1.

		3) Tried EnumResourceNames() for all icons. It only loaded some
		   of them and then gave up. At this point, so did I.

		Result: It is only possible to use 32x32 icons in Neko, although
		these can be scaled up or down as required, resulting in blockyness
		etc.

	*/

    //set initial state
	SetState( STOP );

    //set initial action — modulus range must be the bounds' width/height
    //(not an absolute right/bottom, which can be negative on multi-monitor).
    {
        const RECT rcB = m_pPet->GetBoundsRect();
        m_nActionX = rcB.left + ( rand() % ( rcB.right  - rcB.left - (m_dwSpeed * 8) ) );
        m_nActionY = rcB.top  + ( rand() % ( rcB.bottom - rcB.top  - (m_dwSpeed * 8) ) );
    }
    m_nActionDX = ((( rand() % 2 ) ? 1 : -1) * (m_dwSpeed/2)) + 1;
	m_nActionDY = ((( rand() % 2 ) ? 1 : -1) * (m_dwSpeed/2)) + 1;

    //set initial position (random)
    m_nToX = m_pPet->GetBoundsRect().left + ( rand() % ( (m_pPet->GetBoundsRect().right- m_pPet->GetSize().cx) - m_pPet->GetBoundsRect().left ) ) ;
    m_nToY = m_pPet->GetBoundsRect().top + ( rand() % ( (m_pPet->GetBoundsRect().bottom - m_pPet->GetSize().cy) - m_pPet->GetBoundsRect().top ) );
	
	m_pPet->MoveTo( m_nToX, m_nToY );

	//deal with error (fixme?)
	/*
	if( fLoadProblems )
		throw ICON_EXCEPTION;
	*/
}

CNeko::~CNeko()
{
	delete m_pPet;
    for( int i = 0; i < 8; i++ ) if( m_hIconFootprints[i] ) DestroyIcon( m_hIconFootprints[i] );
}

BOOL CNeko::MoveStart()
{
    return( !(( m_nOldToX >= m_nToX-(int)m_dwIdleSpace ) && 
              ( m_nOldToX <= m_nToX+(int)m_dwIdleSpace ) &&
              ( m_nOldToY >= m_nToY-(int)m_dwIdleSpace ) && 
              ( m_nOldToY <= m_nToY+(int)m_dwIdleSpace )));
}

void CNeko::CalcDirection()
{
    State NewState;
    double LargeX, LargeY, Length, SinTheta;

    if( (m_nDX == 0) && (m_nDY == 0) )
        NewState = STOP;
    else 
    {
        LargeX = (double)m_nDX;
        LargeY = (double)(-m_nDY);
        Length = sqrt(LargeX * LargeX + LargeY * LargeY);
        SinTheta = LargeY / Length;

        if( m_nDX > 0 )
        {
            if( SinTheta > g_dSinPiPer8Times3 )
                NewState = U_MOVE;
            else 
                if( (SinTheta <= g_dSinPiPer8Times3 ) && ( SinTheta > g_dSinPiPer8 ) ) 
                    NewState = UR_MOVE;
                else 
                    if( (SinTheta <= g_dSinPiPer8) && (SinTheta > -(g_dSinPiPer8) ) ) 
                        NewState = R_MOVE;
                    else 
                        if( (SinTheta <= -(g_dSinPiPer8) ) && (SinTheta > -(g_dSinPiPer8Times3) ) ) 
                            NewState = DR_MOVE;
                        else 
                            NewState = D_MOVE;
        }
        else 
        {
            if( SinTheta > g_dSinPiPer8Times3 )
                NewState = U_MOVE;
            else 
                if( (SinTheta <= g_dSinPiPer8Times3) && (SinTheta > g_dSinPiPer8) ) 
                    NewState = UL_MOVE;
                else 
                    if( (SinTheta <= g_dSinPiPer8) && (SinTheta > -(g_dSinPiPer8) ) )
                        NewState = L_MOVE;
                    else 
                        if( (SinTheta <= -(g_dSinPiPer8)) && (SinTheta > -(g_dSinPiPer8Times3) ) ) 
                            NewState = DL_MOVE;
                        else 
                            NewState = D_MOVE;
        }
    }

    if( m_State != NewState ) SetState( NewState );

}

void CNeko::RunTowards(int nX, int nY)
{
	//store old and new target
    m_nOldToX = m_nToX; m_nOldToY = m_nToY;
    m_nToX = nX; m_nToY = nY;

	//calculate distance to target and set delta positions
    double dLargeX, dLargeY, dDoubleLength, dLength;
    dLargeX = (double)(m_nToX - m_pPet->GetPosition().x - (int)m_pPet->GetSize().cx / 2); //stop in middle of cursor
    dLargeY = (double)(m_nToY - m_pPet->GetPosition().y - (int)m_pPet->GetSize().cy + 1); //...and just above
    dDoubleLength = dLargeX * dLargeX + dLargeY * dLargeY;

    if( dDoubleLength != 0.0 ) 
    {
        dLength = sqrt( dDoubleLength );
        if( dLength <= (int)m_dwSpeed ) 
        {
			//less than top speed - jump the gap!
            m_nDX = (int)dLargeX;
            m_nDY = (int)dLargeY;
        } 
        else 
        {
			//more than top speed - run at top speed towards target
            m_nDX = (int)(((int)m_dwSpeed * dLargeX) / dLength );
            m_nDY = (int)(((int)m_dwSpeed * dLargeY) / dLength );
        }
    } 
    else //we're at the target - stop
		m_nDX = m_nDY = 0;

    //increment animation counter
    if ( ++m_uTickCount >= MAX_TICK ) m_uTickCount = 0;
    
    if ( m_uTickCount%2 == 0 )
        if (m_uStateCount < MAX_TICK) m_uStateCount++;

    //change state
    switch( m_State ) 
    {
        case STOP:
            if( MoveStart() )
                SetState( AWAKE );
            else if( m_uStateCount >= STOP_TIME )
            {
                const RECT rcB = m_pPet->GetBoundsRect();
                const POINT pt = m_pPet->GetPosition();
                const SIZE sz = m_pPet->GetSize();
                if( m_nDX < 0 && pt.x <= rcB.left )
                    SetState( L_CLAW );
                else if( m_nDX > 0 && pt.x >= rcB.right - sz.cx )
                    SetState( R_CLAW );
                else if( m_nDY < 0 && pt.y <= rcB.top )
                    SetState( U_CLAW );
                else if( m_nDY > 0 && pt.y >= rcB.bottom - sz.cy )
                    SetState( D_CLAW );
                else
                    SetState( WASH );
            }
            m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;

        case WASH:
            if( MoveStart() ) SetState( AWAKE ); 
                else if( m_uStateCount >= WASH_TIME ) SetState( SCRATCH );
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;

        case SCRATCH:
            if( MoveStart() ) SetState( AWAKE ); 
                else if (m_uStateCount >= SCRATCH_TIME ) SetState( YAWN );
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;

        case YAWN:
            if( MoveStart() )  SetState( AWAKE );
                else if (m_uStateCount >= YAWN_TIME) SetState( SLEEP );
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;
        
        case SLEEP:
            if( MoveStart() ) SetState( AWAKE );
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;
        
        case AWAKE:
            if( m_uStateCount >= (UINT)(AWAKE_TIME + (rand()%20)) ) CalcDirection();
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;
       
        case U_MOVE:
        case D_MOVE:
        case L_MOVE:
        case R_MOVE:
        case UL_MOVE:
        case UR_MOVE:
        case DL_MOVE:
        case DR_MOVE:
		{
			//make sure Neko does not go outside boundary area — use the bounds'
			//absolute coordinates (which may start at negative X/Y on multi-monitor
			//virtual-screen setups with a secondary monitor left of / above primary).
            const RECT rcB = m_pPet->GetBoundsRect();
            int nX = m_pPet->GetPosition().x, nY = m_pPet->GetPosition().y;
			int nNewX = nX + m_nDX, nNewY = nY + m_nDY;
            const int nMinX = rcB.left, nMinY = rcB.top;
            const int nMaxX = rcB.right  - m_pPet->GetSize().cx;
            const int nMaxY = rcB.bottom - m_pPet->GetSize().cy;
			BOOL fOutside = ( nNewX <= nMinX || nNewX >= nMaxX || nNewY <= nMinY || nNewY >= nMaxY );

			//change the image and move Neko
	        CalcDirection();

            //clip new x and y positions and see if we've moved anywhere
            if( nNewX < nMinX ) nNewX = nMinX; else if( nNewX > nMaxX ) nNewX = nMaxX;
            if( nNewY < nMinY ) nNewY = nMinY; else if( nNewY > nMaxY ) nNewY = nMaxY;
            BOOL fNotMoved = ( nNewX == nX ) && ( nNewY == nY );

            //stop if we can't go any further
            if( fOutside && fNotMoved )
                SetState(STOP);
			else
            {
				m_pPet->SetImageAndMoveTo( GetStateAnimationFrameIndex(), nNewX, nNewY );
                if( m_bFootprints )
                {
                    int iFpAnim = -1;
                    switch( m_State )
                    {
                        case U_MOVE:  iFpAnim = 0; break;
                        case D_MOVE:  iFpAnim = 4; break;
                        case L_MOVE:  iFpAnim = 6; break;
                        case R_MOVE:  iFpAnim = 2; break;
                        case UL_MOVE: iFpAnim = 7; break;
                        case UR_MOVE: iFpAnim = 1; break;
                        case DL_MOVE: iFpAnim = 5; break;
                        case DR_MOVE: iFpAnim = 3; break;
                        default: break;
                    }
                    if( iFpAnim != -1 )
                    {
                        if( m_uTickCount & 1 )
                            m_pPet->DrawOnTarget( nX-(m_nDY/2), nY, m_hIconFootprints[iFpAnim] );
                        else
                            m_pPet->DrawOnTarget( nX, nY-(m_nDX/2), m_hIconFootprints[iFpAnim] );
                    }
                }
            }
            break;
		}
        
        case U_CLAW:
        case D_CLAW:
        case L_CLAW:
        case R_CLAW:
            if( MoveStart() ) SetState( AWAKE );
                else if( m_uStateCount >= CLAW_TIME ) SetState( SCRATCH );
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;

        default:
            //something bad has happened!
            MessageBeep( 0xFFFFFFFF );
            SetState( STOP );
			m_pPet->SetImage( GetStateAnimationFrameIndex() );
            break;
    }
}

int CNeko::GetStateAnimationFrameIndex()
{
    if ( m_State != SLEEP )
		return m_nAnimation[m_State][m_uTickCount & 0x1];
    else 
        return m_nAnimation[m_State][(m_uTickCount>>2) & 0x1];

}

void CNeko::SetState( State state )
{
    //reset the animation counters
    m_uTickCount = 0;
    m_uStateCount = 0;

    //update the state
    m_State = state;
}


BOOL CNeko::LoadImages()
{
	/* Note: The icons should be in the following order in the file:

	    Awake
		Up 1
		Up 2
		Up Right 1
		Up Right 2
		Right 1
		Right 2
		Down Right 1
		Down Right 2
		Down 1
		Down 2
		Down Left 1
		Down Left 2
		Left 1
		Left 2
		Up Left 1
		Up Left 2
		Up Claw 1
		Up Claw 2
		Right Claw 1
		Right Claw 2
		Left Claw 1
		Left Claw 2
		Down Claw 1
		Down Claw 2
		Wash 2
		Scratch 1
		Scratch 2
		Yawn 1
		Yawn 2
		Sleep 1
		Sleep 2
	*/

	//resolve the skin index against the shared skin table (invalid values
	//fall back to the default skin, matching the constructor clamp)
	int nSkin = (m_nSkin >= 0 && m_nSkin < (int)NEKO_NUM_SKINS) ? m_nSkin : 0;

	//acquire the skin's shared icon table from the skin cache. The table is
	//loaded once on first use and then shared by every pet drawing this
	//skin; it is freed again when the last pet switches away from it.
	//(transfers one reference, which the pet adopts below)
	SkinIconTable* pTable = SkinCache_AcquireIcons( nSkin );

	//fall back to the default skin when the requested skin is missing or
	//corrupt (the cache only publishes tables with all 32 frames present)
	if( pTable == nullptr && nSkin != 0 )
	{
		nSkin = 0;
		pTable = SkinCache_AcquireIcons( 0 );
	}

	if( pTable == nullptr )
	{
        WCHAR szBuffer[1024];
        wsprintfW( szBuffer, L"There are not enough icons in this icon library\n%s\nIt must contain at least 32 icons", m_szLibname );
        MessageBoxW( nullptr, szBuffer, L"Error", MB_ICONERROR|MB_TASKMODAL );
		return FALSE;
	}

	//apply icons (the pet adopts the reference; the previously used skin's
	//icons are released inside SetImages, after the new table is in place)
	m_nSkin = nSkin;
	m_pPet->SetImages( pTable );

    //load footprints
    if( m_bFootprints )
    {
        UINT uID[] = { IDI_FP_UP, IDI_FP_UPRIGHT, IDI_FP_RIGHT, IDI_FP_DOWNRIGHT, IDI_FP_DOWN, IDI_FP_DOWNLEFT, IDI_FP_LEFT, IDI_FP_UPLEFT };
        for( int n = 0; n < 8; n++ ) m_hIconFootprints[n] = LoadIconW( g_hInstance, MAKEINTRESOURCEW(uID[n]) );
    }

	return TRUE;
}

/********************************************************************************************************/

//falling physics constants (per-tick units)
#define NEKO_FALL_GRAVITY     2    //velocity gained every tick
#define NEKO_FALL_MAX_SPEED   64   //terminal velocity
#define NEKO_FALL_BOUNCE_KEEP 2    //bounce speed = impact speed / this
#define NEKO_FALL_BOUNCE_MIN  4    //minimum upward speed to bounce again

/* DoFall - gravity: accelerate downward, bounce off the work-area floor
   with a decaying vertical speed and settle after a few bounces */
void CNeko::DoFall()
{
    //current position and size
    POINT pt = m_pPet->GetPosition();
    SIZE  sz = m_pPet->GetSize();

    //the floor is the bottom of the work area the pet lives on
    RECT rcWork = m_pPet->GetWorkArea();
    int nFloorY = rcWork.bottom - sz.cy;

    //gravity increases the downward velocity every tick (capped)
    m_nFallVel += NEKO_FALL_GRAVITY;
    if( m_nFallVel > NEKO_FALL_MAX_SPEED ) m_nFallVel = NEKO_FALL_MAX_SPEED;

    m_uTickCount++;

    //integrate the position from the current velocity
    int nNewY = pt.y + m_nFallVel;
    if( nNewY >= nFloorY )
    {
        //floor collision: bounce up with part of the impact speed
        int nBounceVel = -m_nFallVel / NEKO_FALL_BOUNCE_KEEP;
        if( -nBounceVel < NEKO_FALL_BOUNCE_MIN )
        {
            //too slow to bounce again: settle on the floor
            m_fFalling = FALSE;
            m_nFallVel = 0;
            m_nToX = pt.x;    m_nToY = nFloorY;
            m_nOldToX = pt.x; m_nOldToY = nFloorY;
            m_pPet->SetImageAndMoveTo( GetStateAnimationFrameIndex(), pt.x, nFloorY );
            SetState( STOP );
        }
        else
        {
            //bounce: flip the velocity upward; gravity pulls it back down
            //over the following ticks, each bounce losing half the energy
            m_nFallVel = nBounceVel;
            m_pPet->SetImageAndMoveTo( GetStateAnimationFrameIndex(), pt.x, nFloorY );
        }
    }
    else
    {
        //in flight (falling or rising after a bounce)
        m_pPet->SetImageAndMoveTo( GetStateAnimationFrameIndex(), pt.x, nNewY );
    }
}

/* SaveCatInt - persist a per-cat integer setting into config.ini */
void CNeko::SaveCatInt( LPCWSTR szKeyName, DWORD dwValue )
{
    WCHAR szKey[MAX_PATH];
    lstrcpyW( szKey, szNekoCfgSection );
    if( lstrlenW( m_szName ) > 0 )
    {
        lstrcatW( szKey, L"\\" );
        lstrcatW( szKey, m_szName );
    }

    CNekoSettings NekoSettings( szKey );
    if( NekoSettings.IsOpen() )
        NekoSettings.SetInt( szKeyName, dwValue );
}

/* SetSkin - switch to another built-in skin (index into kNekoSkins) */
void CNeko::SetSkin( int nSkin )
{
    if( nSkin < 0 ) nSkin = 0;
    if( nSkin >= (int)NEKO_NUM_SKINS ) nSkin = 0;
    if( nSkin == m_nSkin ) return;

    m_nSkin = nSkin;
    SaveCatInt( szNekoSkinKey, (DWORD)m_nSkin );

    if( LoadImages() )
        m_pPet->SetImage( GetStateAnimationFrameIndex() );
}

/* SetScalePercent - resize the pet (25% - 400%) */
void CNeko::SetScalePercent( DWORD dwPercent )
{
    if( dwPercent < 25 ) dwPercent = 25;
    if( dwPercent > 400 ) dwPercent = 400;
    if( dwPercent == m_dwScale ) return;

    m_dwScale = dwPercent;
    SaveCatInt( szNekoScaleKey, m_dwScale );

    m_pPet->SetScale( ((float)m_dwScale / 100.0f) );
    m_pPet->OnScaleChanged();
}

/********************************************************************************************************/

void CNeko::Update()
{
    //if the pet was just dropped above the work-area floor, start falling
    if( m_pPet->IsFallPending() )
    {
        m_pPet->ClearFallPending();
        m_fFalling = TRUE;
        m_nFallVel = 2;
        //show the calm, settled pose while airborne instead of the
        //running-towards-mouse animation; the physics below still runs
        SetState( FALL );
    }

    //falling physics overrides everything else
    if( m_fFalling )
    {
        DoFall();
        return;
    }

    //apply VVPAI (very, very poor artificial intelligence!!!)
    switch( m_Action )
    {
        default:
        case CHASE_MOUSE:
        {
	        POINT pt;
	        GetCursorPos( &pt );
	        RunTowards( pt.x, pt.y );
            break;
        }

        case RUN_AWAY_FROM_MOUSE:
        {
            POINT pt;
            int xdiff, ydiff;
            GetCursorPos( &pt );
			DWORD dwLimit = m_dwIdleSpace*16;

			xdiff = ( m_pPet->GetPosition().x + (m_pPet->GetSize().cx/2) ) - pt.x;
			ydiff = ( m_pPet->GetPosition().y + (m_pPet->GetSize().cy/2) ) - pt.y;

			if( abs(xdiff) < (int)dwLimit && abs(ydiff) < (int)dwLimit )
			{
				//mouse cursor is too close
				int x, y;
				double dLength = sqrt((double)xdiff*xdiff + ydiff*ydiff);
				if( dLength != 0.0 )
				{
					x = m_pPet->GetPosition().x + (int)((xdiff / dLength) * dwLimit);
					y = m_pPet->GetPosition().y + (int)((ydiff / dLength) * dwLimit);
				}
				else
					x = y = 32;

				//make Neko run away from the mouse
                RunTowards( x, y );
                if( m_State == AWAKE ) CalcDirection(); //don't show awake animation
			}
			else
				RunTowards( m_nToX, m_nToY ); //keep running...
			break;
		}

        case RUN_AROUND_RANDOMLY:
        {
            if( m_State == SLEEP) m_nActionCount++;
            if( m_nActionCount > (int)m_dwIdleSpace*10 )
            {
                m_nActionCount = 0;
                RunTowards( m_pPet->GetBoundsRect().left + (rand() % (m_pPet->GetBoundsRect().right-m_pPet->GetBoundsRect().left)), m_pPet->GetBoundsRect().top + (rand() % (m_pPet->GetBoundsRect().bottom-m_pPet->GetBoundsRect().top)) );
            }
            else
                RunTowards( m_nToX, m_nToY );
            break;
        }

        case PACE_AROUND_SCREEN:
        {
            if( (m_nDX == 0) && (m_nDY == 0) ) m_nActionCount = ( m_nActionCount + 1 ) % 4;
            switch( m_nActionCount )
            {
                case 0: RunTowards( m_pPet->GetBoundsRect().left + m_pPet->GetSize().cx, m_pPet->GetBoundsRect().top + m_pPet->GetSize().cy ); break;
                case 1: RunTowards( m_pPet->GetBoundsRect().left + m_pPet->GetSize().cx, m_pPet->GetBoundsRect().bottom - m_pPet->GetSize().cy ); break;
                case 2: RunTowards( m_pPet->GetBoundsRect().right - m_pPet->GetSize().cx, m_pPet->GetBoundsRect().bottom - m_pPet->GetSize().cy ); break;
                case 3: RunTowards( m_pPet->GetBoundsRect().right - m_pPet->GetSize().cx, m_pPet->GetBoundsRect().top + m_pPet->GetSize().cy ); break;
            }
            break;
        }

        case RUN_AROUND:
        {
			//bounding box repel border
			DWORD dwBoundingBox = m_dwSpeed * 8;

			//move invisible ball
            m_nActionX += m_nActionDX;
            m_nActionY += m_nActionDY;
			
			//repel invisible ball from the edges of the screen.
			if( m_nActionX < (int)(m_pPet->GetBoundsRect().left + dwBoundingBox) )
			{
				if( m_nActionX > m_pPet->GetBoundsRect().left ) m_nActionDX++;
				else m_nActionDX = -m_nActionDX;
			}
			else if( m_nActionX > (int)(m_pPet->GetBoundsRect().right - dwBoundingBox) )
			{
				if( m_nActionX < m_pPet->GetBoundsRect().right ) m_nActionDX--;
				else m_nActionDX = -m_nActionDX;
			}

			if( m_nActionY < (int)(m_pPet->GetBoundsRect().top + dwBoundingBox) )
			{
				if( m_nActionY > m_pPet->GetBoundsRect().top ) m_nActionDY++;
				else m_nActionDY = -m_nActionDY;
			}
			else if( m_nActionY > (int)(m_pPet->GetBoundsRect().bottom - dwBoundingBox) )
			{
				if( m_nActionY < m_pPet->GetBoundsRect().bottom ) m_nActionDY--;
				else m_nActionDY = -m_nActionDY;
			}

			//tell Neko to run towards the new point
            RunTowards( m_nActionX, m_nActionY );
            break;
        }
    }
}

