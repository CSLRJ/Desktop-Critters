// SkinCache.cpp: process-wide, reference-counted cache of skin images.
//
// Replaces the previous per-pet image ownership: CNeko::LoadImages used to
// load a private set of 32 icons for every pet and CPet::SetImages used to
// CopyIcon() the whole table again, so N pets on the same skin each held
// their own icon copies and rebuilt their own window regions. Everything
// is now shared per (skin, scale) and freed as soon as the last user of a
// skin releases it.
//////////////////////////////////////////////////////////////////////

#include "SkinCache.h"

//cache storage (one fixed slot per built-in skin)
static SkinIconTable  g_Tables[NEKO_NUM_SKINS];
static SkinRegionSet* g_RegionHeads[NEKO_NUM_SKINS];

//external global variable
extern HINSTANCE g_hInstance;

//////////////////////////////////////////////////////////////////////
// Icon tables
//////////////////////////////////////////////////////////////////////

SkinIconTable* SkinCache_AcquireIcons( int nSkin )
{
    if( nSkin < 0 || nSkin >= (int)NEKO_NUM_SKINS ) return nullptr;

    SkinIconTable* pTable = &g_Tables[nSkin];

    //already loaded: just hand out another reference
    if( pTable->nRefs > 0 )
    {
        pTable->nRefs++;
        return pTable;
    }

    //load all frames of the skin from this executable's resources.
    //LR_SHARED must NOT be used: shared icons cannot be freed, which would
    //defeat the release-on-last-use policy for switched-away skins.
    HICON* phIcons = new HICON[NEKO_SKIN_FRAMES];
    int n;
    for( n = 0; n < NEKO_SKIN_FRAMES; n++ )
    {
        phIcons[n] = (HICON)LoadImageW( g_hInstance,
            MAKEINTRESOURCEW( kNekoSkins[nSkin].nIconFirst + n ),
            IMAGE_ICON, 0, 0, LR_DEFAULTSIZE );
    }

    //a skin is only usable when every frame of it loaded; keep iterating
    //so that whatever did load gets destroyed below
    BOOL fComplete = TRUE;
    for( n = 0; n < NEKO_SKIN_FRAMES; n++ )
    {
        if( phIcons[n] == nullptr || (INT_PTR)phIcons[n] <= 1 ) fComplete = FALSE;
    }

    //record the native (unscaled) mask size of the first frame
    SIZE sizeOriginal = { 0, 0 };
    if( fComplete )
    {
        ICONINFO ii;
        if( GetIconInfo( phIcons[0], &ii ) )
        {
            BITMAP bm;
            if( GetObject( ii.hbmMask, sizeof(BITMAP), &bm ) == sizeof(BITMAP) )
            {
                sizeOriginal.cx = bm.bmWidth;
                sizeOriginal.cy = bm.bmHeight;
            }
            DeleteObject( ii.hbmMask );
            if( ii.hbmColor != nullptr ) DeleteObject( ii.hbmColor );
        }
    }

    if( !fComplete || sizeOriginal.cx <= 0 || sizeOriginal.cy <= 0 )
    {
        //missing/corrupt skin: caller falls back to the default skin
        for( n = 0; n < NEKO_SKIN_FRAMES; n++ )
        {
            if( phIcons[n] != nullptr && (INT_PTR)phIcons[n] > 1 ) DestroyIcon( phIcons[n] );
        }
        delete[] phIcons;
        return nullptr;
    }

    //publish the new table with a single reference for the caller
    pTable->phIcons      = phIcons;
    pTable->nIcons       = NEKO_SKIN_FRAMES;
    pTable->sizeOriginal = sizeOriginal;
    pTable->nRefs        = 1;
    return pTable;
}

void SkinCache_ReleaseIcons( SkinIconTable* pTable )
{
    if( pTable == nullptr || pTable->nRefs <= 0 ) return;

    //still referenced elsewhere?
    if( --pTable->nRefs > 0 ) return;

    //last user gone: destroy every icon of the skin
    for( int i = 0; i < pTable->nIcons; i++ )
    {
        if( pTable->phIcons[i] != nullptr ) DestroyIcon( pTable->phIcons[i] );
    }
    delete[] pTable->phIcons;
    pTable->phIcons      = nullptr;
    pTable->nIcons       = 0;
    pTable->sizeOriginal.cx = 0;
    pTable->sizeOriginal.cy = 0;

    //defensive: purge any region sets of this skin that are no longer used
    //(normally there are none: every pet holds a reference to both the
    //table and its region set, so they are released together)
    const int nSkin = (int)( pTable - g_Tables );
    SkinRegionSet* pSet = g_RegionHeads[nSkin];
    while( pSet != nullptr )
    {
        SkinRegionSet* pNext = pSet->pNext;
        while( pSet->nRefs > 0 ) SkinCache_ReleaseRegions( pSet );
        pSet = pNext;
    }
    g_RegionHeads[nSkin] = nullptr;
}

//////////////////////////////////////////////////////////////////////
// Region sets (shared per skin + scale)
//////////////////////////////////////////////////////////////////////

//Builds the per-frame window regions from a skin's icon masks. This is the
//former CAlwaysOnTopPet::BuildRegions, parameterised on the shared table so
//the result can be reused by every pet drawing the same skin at the same
//scale. Individual entries may be null if ExtCreateRegion failed; drawing
//falls back to a rectangular window in that case (pre-existing behaviour).
//Based on the BitmapToRegion function found in www.codeguru.com's
//"bitmaps and palettes" section, June 1998.
static HRGN* BuildRegionSet( const SkinIconTable* pTable, float fScale )
{
    //create a memory DC inside which we will scan the bitmap content
    HDC hMemDC = CreateCompatibleDC(nullptr);

    //create a 16-bpp bitmap at the icon's native (unscaled) size and select
    //it into the memory DC. Using the table's stored sizeOriginal instead of
    //recovering the size via int(m_sizeImage.cx/m_fScale) - the latter
    //truncates at fractional scales and undersizes the DIB by 1 pixel,
    //causing the scan loop below to read past the buffer on the last row
    //(silent on XP, access violation on Vista+).
    BITMAPINFOHEADER bi = { sizeof(BITMAPINFOHEADER), pTable->sizeOriginal.cx, pTable->sizeOriginal.cy, 1, 16, BI_RGB, 0, 0, 0, 0, 0 };
    VOID* pBitsDib;
    HBITMAP hBmDib = CreateDIBSection( hMemDC, (BITMAPINFO*)&bi, DIB_RGB_COLORS, &pBitsDib, nullptr, 0 );
    HBITMAP hOldMemBmp = (HBITMAP)SelectObject( hMemDC, hBmDib );

    //create a DC just to copy the bitmap into the memory DC
    HDC hDC = CreateCompatibleDC( hMemDC );

    //get how many bytes per row we have for the bitmap bits (rounded up to 32 bits)
    BITMAP bmDib;
    GetObject( hBmDib, sizeof(bmDib), &bmDib );
    while( bmDib.bmWidthBytes % 4 ) bmDib.bmWidthBytes++;

    //calculate scaling matrix
    XFORM xForm = { fScale, 0.0, 0.0, fScale, 0.0, 0.0 };

    //allocate the region array
    HRGN* phRgns = new HRGN[pTable->nIcons];

    //allocate the RGNDATA scratch buffer once for the whole set and grow it
    //in ALLOC_UNIT steps only when a frame actually needs more rectangles.
    //The former per-icon GlobalAlloc/ReAlloc/Free cycle churned the heap and
    //left retained pages behind on every skin switch.
    #define ALLOC_UNIT 100
    DWORD dwMaxRects = ALLOC_UNIT;
    HANDLE hData = GlobalAlloc( GMEM_MOVEABLE, sizeof(RGNDATAHEADER) + (sizeof(RECT) * dwMaxRects) );
    RGNDATA* pData = (RGNDATA *)GlobalLock( hData );

    //build all regions
    for( int i = 0; i < pTable->nIcons; i++ )
    {
        HRGN hRgn = nullptr;

        //extract icon mask image
        ICONINFO ii;
        GetIconInfo( pTable->phIcons[i], &ii );
        DeleteObject( ii.hbmColor );

        //get bitmap size
        BITMAP bm;
        GetObject( ii.hbmMask, sizeof(bm), &bm );

        //copy the bitmap into the memory DC
        HBITMAP hOldBmp = (HBITMAP)SelectObject( hDC, ii.hbmMask );
        BitBlt( hMemDC, 0, 0, bm.bmWidth, bm.bmHeight, hDC, 0, 0, SRCCOPY );

        //reset the per-frame region data
        pData->rdh.dwSize = sizeof(RGNDATAHEADER);
        pData->rdh.iType = RDH_RECTANGLES;
        pData->rdh.nCount = pData->rdh.nRgnSize = 0;
        SetRect( &pData->rdh.rcBound, MAXLONG, MAXLONG, 0, 0 );

        //scan each bitmap row from bottom to top (the bitmap is inverted vertically)
        BYTE* pDib = (BYTE*)bmDib.bmBits + (bmDib.bmHeight - 1) * bmDib.bmWidthBytes;
        for( int y = 0; y < bm.bmHeight; y++ )
        {
            //scan each bitmap pixel from left to right
            for( int x = 0; x < bm.bmWidth; x++ )
            {
                //search for a continuous range of "non transparent pixels"
                int x0 = x;
                WORD* p = (WORD*)pDib + x;
                while( x < bm.bmWidth)
                {
                    if( *p != 0 )
                        //This pixel is "transparent"
                        break;

                    p++;
                    x++;
                }

                if( x > x0 )
                {
                    //Add the pixels (x0, y) to (x, y+1) as a new rectangle in the region
                    if( pData->rdh.nCount >= dwMaxRects )
                    {
                        GlobalUnlock(hData);
                        dwMaxRects += ALLOC_UNIT;
                        hData = GlobalReAlloc( hData, sizeof(RGNDATAHEADER) + (sizeof(RECT) * dwMaxRects), GMEM_MOVEABLE );
                        pData = (RGNDATA*)GlobalLock(hData);
                    }
                    RECT* pr = (RECT*)&pData->Buffer;
                    SetRect(&pr[pData->rdh.nCount], x0, y, x, y+1);
                    if (x0 < pData->rdh.rcBound.left) pData->rdh.rcBound.left = x0;
                    if (y < pData->rdh.rcBound.top)   pData->rdh.rcBound.top = y;
                    if (x > pData->rdh.rcBound.right) pData->rdh.rcBound.right = x;
                    if (y+1 > pData->rdh.rcBound.bottom) pData->rdh.rcBound.bottom = y+1;
                    pData->rdh.nCount++;

                    //On Windows98, ExtCreateRegion() may fail if the number of rectangles is too
                    //large (ie: > 4000). Therefore, we have to create the region by multiple steps.
                    if( pData->rdh.nCount == 2000 )
                    {
                        HRGN h = ExtCreateRegion( &xForm, sizeof(RGNDATAHEADER) + (sizeof(RECT) * dwMaxRects), pData);
                        if( hRgn )
                        {
                            CombineRgn( hRgn, hRgn, h, RGN_OR );
                            DeleteObject(h);
                        }
                        else
                            hRgn = h;

                        pData->rdh.nCount = 0;
                        SetRect( &pData->rdh.rcBound, MAXLONG, MAXLONG, 0, 0 );
                    }
                }
            }

            //go to next row (remember, the bitmap is inverted vertically)
            pDib -= bmDib.bmWidthBytes;
        }

        //create or extend the region with the remaining rectangles
        HRGN h = ExtCreateRegion( &xForm, sizeof(RGNDATAHEADER) + (sizeof(RECT) * dwMaxRects), pData );
        if( hRgn )
        {
            CombineRgn( hRgn, hRgn, h, RGN_OR );
            DeleteObject(h);
        }
        else
            hRgn = h;

        //clean up
        DeleteObject( SelectObject( hDC, hOldBmp ) );

        //store the region
        phRgns[i] = hRgn;
    }

    //clean up
    GlobalUnlock(hData);
    GlobalFree(hData);
    DeleteDC(hDC);
    DeleteObject( SelectObject( hMemDC, hOldMemBmp ) );
    DeleteDC( hMemDC );

    return phRgns;
}

SkinRegionSet* SkinCache_AcquireRegions( SkinIconTable* pTable, float fScale )
{
    if( pTable == nullptr || pTable->nRefs <= 0 ) return nullptr;

    const int nSkin = (int)( pTable - g_Tables );

    //reuse an existing set for this skin+scale
    for( SkinRegionSet* pSet = g_RegionHeads[nSkin]; pSet != nullptr; pSet = pSet->pNext )
    {
        if( pSet->fScale == fScale )
        {
            pSet->nRefs++;
            return pSet;
        }
    }

    //first user at this scale: build the regions from the shared icons
    SkinRegionSet* pSet = new SkinRegionSet;
    pSet->fScale = fScale;
    pSet->phRgns = BuildRegionSet( pTable, fScale );
    pSet->nRgns  = pTable->nIcons;
    pSet->nSkin  = nSkin;
    pSet->nRefs  = 1;
    pSet->pNext  = g_RegionHeads[nSkin];
    g_RegionHeads[nSkin] = pSet;
    return pSet;
}

void SkinCache_ReleaseRegions( SkinRegionSet* pSet )
{
    if( pSet == nullptr || pSet->nRefs <= 0 ) return;

    //still referenced elsewhere?
    if( --pSet->nRefs > 0 ) return;

    //last user gone: unlink from the skin's list, delete the regions
    SkinRegionSet** pp = &g_RegionHeads[pSet->nSkin];
    while( *pp != nullptr && *pp != pSet ) pp = &(*pp)->pNext;
    if( *pp == pSet ) *pp = pSet->pNext;

    for( int i = 0; i < pSet->nRgns; i++ )
    {
        if( pSet->phRgns[i] != nullptr ) DeleteObject( pSet->phRgns[i] );
    }
    delete[] pSet->phRgns;
    delete pSet;
}

//////////////////////////////////////////////////////////////////////
// Shutdown safety net
//////////////////////////////////////////////////////////////////////

void SkinCache_Shutdown()
{
    for( int s = 0; s < (int)NEKO_NUM_SKINS; s++ )
    {
        //region sets still in use are freed after their references drop
        SkinRegionSet* pSet = g_RegionHeads[s];
        while( pSet != nullptr )
        {
            SkinRegionSet* pNext = pSet->pNext;
            while( pSet->nRefs > 0 ) SkinCache_ReleaseRegions( pSet );
            pSet = pNext;
        }
        g_RegionHeads[s] = nullptr;

        //force-release any icon table still referenced (leaked refs included)
        SkinIconTable* pTable = &g_Tables[s];
        while( pTable->nRefs > 0 ) SkinCache_ReleaseIcons( pTable );
    }
}

void SkinCache_TrimWorkingSet()
{
    //empty the working set; only pages that are actually used again
    //(heap, stack, DLL code) will softly fault back in
    SetProcessWorkingSetSize( GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1 );
}
