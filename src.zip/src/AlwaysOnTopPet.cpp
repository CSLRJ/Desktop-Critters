// AlwaysOnTopPet.cpp: implementation of the CAlwaysOnTopPet class.
//
//////////////////////////////////////////////////////////////////////

#include "AlwaysOnTopPet.h"

//class name constant
static const wchar_t* g_szOnTopClassName = L"NekoOnTop_Wnd";

//forward declaration
LRESULT CALLBACK WndProc_OnTop( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

//static members
BOOL CAlwaysOnTopPet::m_fRegisteredClass = FALSE;
void (*CAlwaysOnTopPet::s_pfnContextMenu)(CAlwaysOnTopPet*) = nullptr;

//external global variable
extern HINSTANCE g_hInstance;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAlwaysOnTopPet::CAlwaysOnTopPet() : CPet()
{
	//no shared region set yet
	m_pRegionSet = nullptr;
	m_hRgns = nullptr;

	//initialise members
	m_fBeingDragged = FALSE;
	m_hWndOnTop = nullptr;

	//register class
	if( m_fRegisteredClass == FALSE )
	{
		WNDCLASSW wc;

		wc.style         = CS_OWNDC|CS_DBLCLKS|CS_SAVEBITS;
		wc.lpfnWndProc   = (WNDPROC)WndProc_OnTop;
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = sizeof(LPVOID);
		wc.hInstance     = g_hInstance;
		wc.hIcon         = nullptr;
		wc.hCursor       = LoadCursorW( nullptr, IDC_ARROW );
		wc.hbrBackground = nullptr;
		wc.lpszMenuName  = nullptr;
		wc.lpszClassName = g_szOnTopClassName;

		m_fRegisteredClass = RegisterClassW(&wc);
	}

	//set bounding rectangle — span the full virtual screen, respecting a
	//possibly-negative origin if a secondary monitor is left of / above primary.
	{
		const int x  = GetSystemMetrics(SM_XVIRTUALSCREEN);
		const int y  = GetSystemMetrics(SM_YVIRTUALSCREEN);
		const int cx = GetSystemMetrics(SM_CXVIRTUALSCREEN);
		const int cy = GetSystemMetrics(SM_CYVIRTUALSCREEN);
		SetRect(&m_rcBounds, x, y, x + cx - 1, y + cy - 1);
	}

    //move this pet off-screen to start with
    m_ptPosition.x = m_rcBounds.right;
    m_ptPosition.y = m_rcBounds.bottom;
}

CAlwaysOnTopPet::~CAlwaysOnTopPet()
{
	DestroyWindow( m_hWndOnTop );

	//release the shared region set here. ~CPet() calls the *base* version of
	//the virtual DestroyImages(), so without this the region set would leak
	//on every pet destruction (pre-fix behaviour: the 32 per-frame regions
	//and their array were leaked whenever a cat was deleted).
	DestroyRegions();
}



//////////////////////////////////////////////////////////////////////
// Member Functions
//////////////////////////////////////////////////////////////////////

void CAlwaysOnTopPet::Draw( int nImage )
{
	//only draw if it's different && not being dragged
	if( nImage != m_nLastIcon && m_fBeingDragged == FALSE )
	{
		//no image table adopted yet (failed skin load): nothing to show
		if( nImage < 0 || nImage >= m_nIcons ) return;

		//clip the window to the shape of the icon. The region set is shared
		//(cache-owned) and only read here; SetWindowRgn gets a copy and the
		//system owns that copy, so sharing the source regions is safe.
		HRGN hRgnCopy = CreateRectRgn( 0, 0, m_sizeImage.cx, m_sizeImage.cy );
		if( hRgnCopy != nullptr )
		{
			if( m_hRgns != nullptr && m_hRgns[nImage] != nullptr )
				CombineRgn( hRgnCopy, m_hRgns[nImage], nullptr, RGN_COPY );
			//on success the system takes ownership of the region; on failure
			//it does not, and we must delete it ourselves or the HRGN leaks
			if( SetWindowRgn( m_hWndOnTop, hRgnCopy, TRUE ) == 0 )
				DeleteObject( hRgnCopy );
		}

		//draw the current frame on the window
		HDC hDC = GetDC( m_hWndOnTop );
		DrawIconEx( hDC, 0, 0, m_hIcons[nImage], m_sizeImage.cx, m_sizeImage.cy, 0, nullptr, DI_NORMAL );
		ReleaseDC( m_hWndOnTop, hDC );
	}
}

void CAlwaysOnTopPet::Erase()
{
	//do nothing
}

void CAlwaysOnTopPet::SetImages( SkinIconTable* pTable )
{
	//release the previous region set and skin table reference
	DestroyImages();

	//adopt the shared icon table (transfers the caller's cache reference)
	CPet::SetImages( pTable );
	if( pTable == nullptr ) return;

	//share the window regions built for (skin, scale); they are built once
	//on first use and reused by every pet drawing the same skin at the same
	//scale
	m_pRegionSet = SkinCache_AcquireRegions( pTable, m_fScale );
	m_hRgns = ( m_pRegionSet != nullptr ) ? m_pRegionSet->phRgns : nullptr;

	//create the window if it doesn't exist already
	if( m_hWndOnTop == nullptr )
	{
        m_hWndOnTop = CreateWindowExW( WS_EX_TOPMOST|WS_EX_TOOLWINDOW, g_szOnTopClassName, nullptr, WS_POPUP, m_ptPosition.x, m_ptPosition.y, m_sizeImage.cx, m_sizeImage.cy, nullptr, nullptr, g_hInstance, nullptr );

        if( m_hWndOnTop )
        {
            SetWindowLongPtrW( m_hWndOnTop, 0, (LONG_PTR)this );
            ShowWindow( m_hWndOnTop, SW_SHOWNA );
            UpdateWindow( m_hWndOnTop );
        }
	}

	//FIXME: don't change it in the whole class, just this window!!!
	//change it's default icon
	//SetClassLong( m_hWndOnTop, GCL_HICON, m_hIcons[0] );

	//the old skin's GDI/USER objects were released above and the new skin's
	//icon data has been decoded into kernel objects; drop the now-unused
	//resource pages so switching skins does not leave memory resident
	SkinCache_TrimWorkingSet();
}

void CAlwaysOnTopPet::DestroyImages()
{
	//release the shared region set first (it borrows nothing, but keeps the
	//release order of the old implementation)
	DestroyRegions();

	//release the shared skin table reference (base class)
	CPet::DestroyImages();
}





//////////////////////////////////////////////////////////////////////
// On Top Window Procedure
//////////////////////////////////////////////////////////////////////

LRESULT CALLBACK WndProc_OnTop( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_PAINT:
		{
            //draw the most recent icon if the window is being dragged
            CAlwaysOnTopPet* pPet = (CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 );
            if( pPet->m_fBeingDragged && pPet->m_nLastIcon >= 0 && pPet->m_nLastIcon < pPet->m_nIcons )
            {
    			//draw the current icon onto the window (we can't call draw because it checks for icon index and changes the window's region
			    HDC hDC = GetDC( hWnd );
			    DrawIconEx( hDC, 0, 0, pPet->m_hIcons[pPet->m_nLastIcon], pPet->GetSize().cx, pPet->GetSize().cy, 0, nullptr, DI_NORMAL );
			    ReleaseDC( hWnd, hDC );
            }
            ValidateRect( hWnd, nullptr );
            break;
		}

		case WM_SYSCOMMAND:
			//if the user alt+F4s us or (somehow) minimises or maximises us, ignore it
			if( LOWORD(wParam) != SC_CLOSE && LOWORD(wParam) != SC_MINIMIZE && LOWORD(wParam) != SC_MAXIMIZE ) 
			    return DefWindowProcW( hWnd, uMsg, wParam, lParam );
			break;

        case WM_ERASEBKGND:
            return TRUE; //don't erase the background

        //pass mouse messages onto the class
        case WM_LBUTTONDOWN:   ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnLButtonDown(); break;
        case WM_LBUTTONUP:     ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnLButtonUp(); break;
        case WM_LBUTTONDBLCLK: ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnLButtonDblClk(); break;

        case WM_MBUTTONDOWN:   ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnMButtonDown(); break;
        case WM_MBUTTONUP:     ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnMButtonUp(); break;
        case WM_MBUTTONDBLCLK: ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnMButtonDblClk(); break;

        case WM_RBUTTONDOWN:
        {
            //show the pet context menu (hook set up by Neko98.cpp)
            CAlwaysOnTopPet* pPet = (CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 );
            if( CAlwaysOnTopPet::s_pfnContextMenu )
                CAlwaysOnTopPet::s_pfnContextMenu( pPet );
            break;
        }
        case WM_RBUTTONUP:     ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnRButtonUp(); break;
        case WM_RBUTTONDBLCLK: ((CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 ))->OnRButtonDblClk(); break;

        //window is being dragged
        case WM_ENTERSIZEMOVE:
        {
            CAlwaysOnTopPet* pPet = (CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 );
            pPet->m_fBeingDragged = TRUE;
            break;
        }

        //window is being dropped
        case WM_EXITSIZEMOVE:
        {
            CAlwaysOnTopPet* pPet = (CAlwaysOnTopPet*)GetWindowLongPtrW( hWnd, 0 );
            pPet->m_fBeingDragged = FALSE;
            RECT rc;
            GetWindowRect( hWnd, &rc );
            pPet->MoveTo( rc.left, rc.top );

            //if the pet was dropped above the work-area floor, mark it for falling
            RECT rcWork = pPet->GetWorkArea();
            if( rc.bottom < rcWork.bottom )
                pPet->m_fFallPending = TRUE;
            break;
        }

        default:
           return DefWindowProcW( hWnd, uMsg, wParam, lParam );
    }
    return 0;
}

void CAlwaysOnTopPet::OnLButtonDown()
{
    //default left button handler - begin window dragging
    SendMessageW( m_hWndOnTop, WM_SYSCOMMAND, SC_MOVE+2, 0 );
}

void CAlwaysOnTopPet::DestroyRegions()
{
    //the region array is owned by the shared skin cache - drop our
    //reference; the cache deletes the regions when the last user releases
    if( m_pRegionSet != nullptr )
    {
        SkinCache_ReleaseRegions( m_pRegionSet );
        m_pRegionSet = nullptr;
        m_hRgns = nullptr;
    }
}

void CAlwaysOnTopPet::MoveTo(int nNewX, int nNewY)
{
	if( m_fBeingDragged == FALSE )
    {
	    //store current position
	    m_ptOldPosition.x = m_ptPosition.x;
	    m_ptOldPosition.y = m_ptPosition.y;

	    //change current position
	    m_ptPosition.x = nNewX;
	    m_ptPosition.y = nNewY;

	    //move the window if it's not being moved by something else
		MoveWindow( m_hWndOnTop, nNewX, nNewY, m_sizeImage.cx, m_sizeImage.cy, TRUE );
    }
}


void CAlwaysOnTopPet::SetImageAndMoveTo(int nImage, int nNewX, int nNewY)
{
    if( m_fBeingDragged == FALSE )
    {
	    //move
	    MoveTo( nNewX, nNewY );

	    //change image
	    Draw( nImage );
	    m_nLastIcon = nImage;
    }
}

void CAlwaysOnTopPet::SetImage( int nImage )
{
    if( m_fBeingDragged == FALSE ) CPet::SetImage( nImage );
}



//////////////////////////////////////////////////////////////////////
// Scale change: re-acquire regions and resize the window
//////////////////////////////////////////////////////////////////////

void CAlwaysOnTopPet::OnScaleChanged()
{
    if( m_hWndOnTop == nullptr ) return;

    //re-acquire the shared region set for the new scale (the set of the old
    //scale is released; a set for the new scale is built on first use)
    DestroyRegions();
    if( m_pSkinTable != nullptr )
    {
        m_pRegionSet = SkinCache_AcquireRegions( m_pSkinTable, m_fScale );
        m_hRgns = ( m_pRegionSet != nullptr ) ? m_pRegionSet->phRgns : nullptr;
    }
    m_nLastIcon = -1;

    //resize the window (position is kept)
    SetWindowPos( m_hWndOnTop, nullptr, 0, 0, m_sizeImage.cx, m_sizeImage.cy, SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE );
}

RECT CAlwaysOnTopPet::GetWorkArea()
{
    //the work area of the monitor the pet window is currently on
    HMONITOR hMon = MonitorFromWindow( m_hWndOnTop, MONITOR_DEFAULTTONEAREST );
    MONITORINFO mi;
    mi.cbSize = sizeof(MONITORINFO);
    if( hMon != nullptr && GetMonitorInfoW( hMon, &mi ) )
        return mi.rcWork;

    //fall back to the primary monitor's work area
    return CPet::GetWorkArea();
}
